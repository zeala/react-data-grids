<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><!-- start: forumdisplay -->
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=4&page=63 by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:51:02 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<title> - ag-Grid Free Forum (not actively monitored by ag-Grid dev) </title>
<!-- start: headerinclude -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/prototype7321.js?ver=1603"></script>
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/general7321.js?ver=1603"></script>
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/popup_menu0414.js?ver=1600"></script>
<link type="text/css" rel="stylesheet" href="../../ag-grid.com/forum/cache/themes/theme1/global.css" />
<link type="text/css" rel="stylesheet" href="../../ag-grid.com/forum/cache/themes/theme1/star_ratings.css" />

<script type="text/javascript">
<!--
	var cookieDomain = ".ag-grid.com";
	var cookiePath = "index.html";
	var cookiePrefix = "";
	var deleteevent_confirm = "Are you sure you want to delete this event?";
	var removeattach_confirm = "Are you sure you want to remove the selected attachment from this post?";
	var loading_text = 'Loading. <br />Please Wait..';
	var saving_changes = 'Saving changes..';
	var use_xmlhttprequest = "1";
	var my_post_key = "9d9f8e6842db6d8c8a75a10edcf17276";
	var imagepath = "images";
// -->
</script>

<!-- end: headerinclude -->
<!-- start: forumdisplay_rssdiscovery -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads in ag-Grid Free Forum (not actively monitored by ag-Grid dev) (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php?fid=4" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads in ag-Grid Free Forum (not actively monitored by ag-Grid dev) (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0&amp;fid=4" />
<!-- end: forumdisplay_rssdiscovery -->
<script type="text/javascript">
<!--
	lang.no_new_posts = "Forum Contains No New Posts";
	lang.click_mark_read = "Click to mark this forum as read";
// -->
</script>
</head>
<body>
<!-- start: header -->
	<div id="container">
		<a name="top" id="top"></a>
		<div id="header">
			<div class="logo"><a href="index-2.html"><img src="../../ag-grid.com/forum/images/logo.gif" alt="" title="" /></a></div>
			<div class="menu">
				<ul>
					<li><a href="search.php"><img src="images/toplinks/search.gif" alt="" title="" />Search</a></li>
					<li><a href="https://ag-grid.com/forum/memberlist.php"><img src="images/toplinks/memberlist.gif" alt="" title="" />Member List</a></li>
					<li><a href="https://ag-grid.com/forum/calendar.php"><img src="images/toplinks/calendar.gif" alt="" title="" />Calendar</a></li>
					<li><a href="https://ag-grid.com/forum/misc.php?action=help"><img src="images/toplinks/help.gif" alt="" title="" />Help</a></li>
				</ul>
			</div>
			<hr class="hidden" />
			<div id="panel">
				<!-- start: header_welcomeblock_guest -->
<script type="text/javascript">
<!--
	lang.username = "Username";
	lang.password = "Password";
	lang.login = "Login";
	lang.lost_password = " &mdash; <a href=\"member9a16.html?action=lostpw\">Lost Password?<\/a>";
	lang.register_url = " &mdash; <a href=\"member0ddc.php?action=register\">Register<\/a>";
	lang.remember_me = "Remember me";
// -->
</script>
<span style="float: right;"><strong>Current time:</strong> 03-17-2016, 07:50 AM</span>
		<span id="quick_login">Hello There, Guest! (<a href="https://ag-grid.com/forum/member.php?action=login" onclick="MyBB.quickLogin(); return false;">Login</a> &mdash; <a href="member0ddc.php?action=register">Register</a>)</span>
<!-- end: header_welcomeblock_guest -->
			</div>
		</div>
		<hr class="hidden" />
		<br class="clear" />
		<div id="content">
			
			
			
			
			
			<!-- start: nav -->

<div class="navigation">
<!-- start: nav_bit -->
<a href="index-2.html"></a><!-- start: nav_sep -->
 / 
<!-- end: nav_sep -->
<!-- end: nav_bit --><!-- start: nav_bit -->
<a href="forumdisplaye15e.html?fid=3">ag-Grid</a>
<!-- end: nav_bit --><!-- start: nav_sep_active -->
 / 
<!-- end: nav_sep_active --><!-- start: nav_bit_active -->
<span class="active">ag-Grid Free Forum (not actively monitored by ag-Grid dev)</span>
<!-- end: nav_bit_active -->
</div>
<!-- end: nav -->
			<br />

<!-- end: header -->

<!-- start: forumdisplay_usersbrowsing -->
<span class="smalltext">User(s) browsing this forum: 1 Guest(s)</span><br />
<!-- end: forumdisplay_usersbrowsing -->


<!-- start: forumdisplay_threadlist -->
<div class="float_left">
	<!-- start: multipage -->
<div class="pagination">
<span class="pages">Pages (66):</span>
<!-- start: multipage_prevpage -->
<a href="forumdisplay5bfb.php?fid=4&amp;page=62" class="pagination_previous">&laquo; Previous</a>
<!-- end: multipage_prevpage --><!-- start: multipage_start -->
<a href="forumdisplay6925.html?fid=4" class="pagination_first">1</a>  ...
<!-- end: multipage_start --><!-- start: multipage_page -->
<a href="forumdisplaybb17.php?fid=4&amp;page=61" class="pagination_page">61</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="forumdisplay5bfb.php?fid=4&amp;page=62" class="pagination_page">62</a>
<!-- end: multipage_page --><!-- start: multipage_page_current -->
 <span class="pagination_current">63</span>
<!-- end: multipage_page_current --><!-- start: multipage_page -->
<a href="forumdisplay5313.php?fid=4&amp;page=64" class="pagination_page">64</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="forumdisplay2857.html?fid=4&amp;page=65" class="pagination_page">65</a>
<!-- end: multipage_page --><!-- start: multipage_end -->
 <a href="forumdisplay2562.html?fid=4&amp;page=66" class="pagination_last">66</a>
<!-- end: multipage_end --><!-- start: multipage_nextpage -->
<a href="forumdisplay5313.php?fid=4&amp;page=64" class="pagination_next">Next &raquo;</a>
<!-- end: multipage_nextpage -->
</div>
<!-- end: multipage -->
</div>
<div class="float_right">
	<!-- start: forumdisplay_newthread -->
<a href="newthread6925.html?fid=4"><img src="images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<table border="0" cellspacing="1" cellpadding="4" class="tborder" style="clear: both;">
	<tr>
		<td class="thead" colspan="7">
			<div style="float: right;">
				<span class="smalltext"><strong><a href="misc5247.html?action=markread&amp;fid=4">Mark this forum read</a> | <a href="usercp249e8.html?action=addsubscription&amp;type=forum&amp;fid=4&amp;my_post_key=9d9f8e6842db6d8c8a75a10edcf17276">Subscribe to this forum</a></strong></span>
			</div>
			<div>
				<strong>ag-Grid Free Forum (not actively monitored by ag-Grid dev)</strong>
			</div>
		</td>
	</tr>
	<tr>
		<td class="tcat" colspan="3" width="66%"><span class="smalltext"><strong><a href="forumdisplayf9c9.php?fid=4&amp;page=63&amp;datecut=0&amp;sortby=subject&amp;order=asc">Thread</a>  / <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=63&amp;datecut=0&amp;sortby=starter&amp;order=asc">Author</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=63&amp;datecut=0&amp;sortby=replies&amp;order=desc">Replies</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=63&amp;datecut=0&amp;sortby=views&amp;order=desc">Views</a> </strong></span></td>
		<!-- start: forumdisplay_threadlist_rating -->
	<td class="tcat" align="center" width="80">
		<span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=63&amp;datecut=0&amp;sortby=rating&amp;order=desc">Rating</a> </strong></span>
		<script type="text/javascript" src="https://www.ag-grid.com/forum/jscripts/rating.js?ver=1400"></script>
		<script type="text/javascript">
		<!--
			lang.stars = new Array();
			lang.stars[1] = "1 star out of 5";
			lang.stars[2] = "2 stars out of 5";
			lang.stars[3] = "3 stars out of 5";
			lang.stars[4] = "4 stars out of 5";
			lang.stars[5] = "5 stars out of 5";
		// -->
		</script>
	</td>

<!-- end: forumdisplay_threadlist_rating -->
		<td class="tcat" align="right" width="20%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=63&amp;datecut=0&amp;sortby=lastpost&amp;order=desc">Last Post</a> <!-- start: forumdisplay_orderarrow -->
<span class="smalltext">[<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=63&amp;datecut=0&amp;sortby=lastpost&amp;order=asc">asc</a>]</span>
<!-- end: forumdisplay_orderarrow --></strong></span></td>
		
	</tr>
	
	
	<!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2194" class=" subject_old" id="tid_2194">determine the index of row</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=61">AngularGridExplorer</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2194);">3</a></td>
	<td align="center" class="trow1 forumdisplay_regular">476</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2194">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2194">
			<li style="width: 0%" class="current_rating" id="current_rating_2194">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2194, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-21-2015 04:34 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2194&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2191" class=" subject_old" id="tid_2191">Cell content padding breaks column sizing</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=133">xenit-raven</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2191);">3</a></td>
	<td align="center" class="trow2 forumdisplay_regular">353</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2191">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2191">
			<li style="width: 0%" class="current_rating" id="current_rating_2191">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2191, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-20-2015 10:01 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2191&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=101" class=" subject_old" id="tid_101">Table sizing and cell alignment</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=133">xenit-raven</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(101);">3</a></td>
	<td align="center" class="trow1 forumdisplay_regular">838</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_101">
		<ul class="star_rating star_rating_notrated" id="rating_thread_101">
			<li style="width: 80%" class="current_rating" id="current_rating_101">1 Vote(s) - 4 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(101, { width: '80', extra_class: ' star_rating_notrated', current_average: '1 Vote(s) - 4 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-20-2015 08:01 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=101&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=133">xenit-raven</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2188" class=" subject_old" id="tid_2188">Expandable Grid</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=161">LRFalk01</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2188);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">320</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2188">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2188">
			<li style="width: 0%" class="current_rating" id="current_rating_2188">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2188, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-19-2015 11:49 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2188&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=111" class=" subject_old" id="tid_111">change to grouping cell rendering?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=110">chrisperfer</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(111);">2</a></td>
	<td align="center" class="trow1 forumdisplay_regular">546</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_111">
		<ul class="star_rating star_rating_notrated" id="rating_thread_111">
			<li style="width: 0%" class="current_rating" id="current_rating_111">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(111, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-19-2015 09:18 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=111&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=110">chrisperfer</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=109" class=" subject_old" id="tid_109">Buttons in groupInnerCellRenderer</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=67">AfflictedDev</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(109);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">319</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_109">
		<ul class="star_rating star_rating_notrated" id="rating_thread_109">
			<li style="width: 0%" class="current_rating" id="current_rating_109">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(109, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-15-2015 06:21 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=109&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=106" class=" subject_old" id="tid_106">Exporting ideas</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=110">chrisperfer</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(106);">2</a></td>
	<td align="center" class="trow1 forumdisplay_regular">409</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_106">
		<ul class="star_rating star_rating_notrated" id="rating_thread_106">
			<li style="width: 0%" class="current_rating" id="current_rating_106">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(106, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-14-2015 11:31 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=106&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=103" class=" subject_old" id="tid_103">Nested Grid</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=135">Daniel</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(103);">2</a></td>
	<td align="center" class="trow2 forumdisplay_regular">636</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_103">
		<ul class="star_rating star_rating_notrated" id="rating_thread_103">
			<li style="width: 0%" class="current_rating" id="current_rating_103">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(103, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-14-2015 11:03 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=103&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=135">Daniel</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		<!-- start: forumdisplay_thread_attachment_count -->
<div style="float: right;"><img src="https://www.ag-grid.com/forum/images/paperclip.gif" alt="" title="This thread contains 1 attachment." /></div>
<!-- end: forumdisplay_thread_attachment_count -->
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=102" class=" subject_old" id="tid_102">Grouping</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=5">UrvishNZ</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(102);">3</a></td>
	<td align="center" class="trow1 forumdisplay_regular">408</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_102">
		<ul class="star_rating star_rating_notrated" id="rating_thread_102">
			<li style="width: 0%" class="current_rating" id="current_rating_102">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(102, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-13-2015 10:54 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=102&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=100" class=" subject_old" id="tid_100">detect sorted column in cellRenderer</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=130">lordvogo</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(100);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">227</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_100">
		<ul class="star_rating star_rating_notrated" id="rating_thread_100">
			<li style="width: 0%" class="current_rating" id="current_rating_100">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(100, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-13-2015 06:49 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=100&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=95" class=" subject_old" id="tid_95">Developing With Webstorm</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=107">timctrahan</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(95);">2</a></td>
	<td align="center" class="trow1 forumdisplay_regular">369</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_95">
		<ul class="star_rating star_rating_notrated" id="rating_thread_95">
			<li style="width: 0%" class="current_rating" id="current_rating_95">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(95, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-13-2015 02:38 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=95&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=107">timctrahan</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=88" class=" subject_old" id="tid_88">Update pagination bar on next or previous button click</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=95">prateekduggal</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(88);">6</a></td>
	<td align="center" class="trow2 forumdisplay_regular">732</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_88">
		<ul class="star_rating star_rating_notrated" id="rating_thread_88">
			<li style="width: 0%" class="current_rating" id="current_rating_88">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(88, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-12-2015 12:16 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=88&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=114">akrsmv</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=99" class=" subject_old" id="tid_99">quickfilter</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=61">AngularGridExplorer</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(99);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">240</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_99">
		<ul class="star_rating star_rating_notrated" id="rating_thread_99">
			<li style="width: 0%" class="current_rating" id="current_rating_99">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(99, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-11-2015 10:58 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=99&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=96" class=" subject_old" id="tid_96">Sorting groups</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=51">kmitchell</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(96);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">293</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_96">
		<ul class="star_rating star_rating_notrated" id="rating_thread_96">
			<li style="width: 0%" class="current_rating" id="current_rating_96">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(96, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-11-2015 10:48 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=96&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=92" class=" subject_old" id="tid_92">basic question:  ag-grid versus ui-grid</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=99">mattm</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(92);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">683</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_92">
		<ul class="star_rating star_rating_notrated" id="rating_thread_92">
			<li style="width: 0%" class="current_rating" id="current_rating_92">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(92, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-11-2015 10:42 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=92&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		<!-- start: forumdisplay_thread_attachment_count -->
<div style="float: right;"><img src="https://www.ag-grid.com/forum/images/paperclip.gif" alt="" title="This thread contains 1 attachment." /></div>
<!-- end: forumdisplay_thread_attachment_count -->
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=94" class=" subject_old" id="tid_94">Row Filter</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=119">unal</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(94);">2</a></td>
	<td align="center" class="trow2 forumdisplay_regular">352</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_94">
		<ul class="star_rating star_rating_notrated" id="rating_thread_94">
			<li style="width: 0%" class="current_rating" id="current_rating_94">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(94, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-11-2015 09:58 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=94&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=119">unal</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=90" class=" subject_old" id="tid_90">support for field=&quot;a.b.c.d&quot; in column definitions</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=114">akrsmv</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(90);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">276</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_90">
		<ul class="star_rating star_rating_notrated" id="rating_thread_90">
			<li style="width: 0%" class="current_rating" id="current_rating_90">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(90, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-08-2015 06:49 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=90&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=86" class=" subject_old" id="tid_86">Minor Annoyance on Scrolling</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=108">js_couch_potato</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(86);">3</a></td>
	<td align="center" class="trow2 forumdisplay_regular">444</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_86">
		<ul class="star_rating star_rating_notrated" id="rating_thread_86">
			<li style="width: 100%" class="current_rating" id="current_rating_86">1 Vote(s) - 5 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(86, { width: '100', extra_class: ' star_rating_notrated', current_average: '1 Vote(s) - 5 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-08-2015 06:46 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=86&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=87" class=" subject_old" id="tid_87">Server side paging</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=95">prateekduggal</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(87);">6</a></td>
	<td align="center" class="trow1 forumdisplay_regular">691</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_87">
		<ul class="star_rating star_rating_notrated" id="rating_thread_87">
			<li style="width: 0%" class="current_rating" id="current_rating_87">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(87, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-08-2015 02:51 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=87&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=73" class=" subject_old" id="tid_73">Best way to select all rows</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=49">thomas3577</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(73);">6</a></td>
	<td align="center" class="trow2 forumdisplay_regular">907</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_73">
		<ul class="star_rating star_rating_notrated" id="rating_thread_73">
			<li style="width: 100%" class="current_rating" id="current_rating_73">1 Vote(s) - 5 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(73, { width: '100', extra_class: ' star_rating_notrated', current_average: '1 Vote(s) - 5 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-07-2015 03:05 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=73&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=95">prateekduggal</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread -->
	<tr>
		<td class="tfoot" align="right" colspan="7">
			<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
				<input type="hidden" name="selectall" value="" />
				<input type="hidden" name="fid" value="4" />
				<select name="sortby">
					<option value="subject" >Sort by: Subject</option>
					<option value="lastpost" selected="selected">Sort by: Last Post</option>
					<option value="starter" >Sort by: Author</option>
					<option value="started" >Sort by: Creation Time</option>
					<!-- start: forumdisplay_threadlist_sortrating -->
<option value="rating" >Sort by: Rating</option>
<!-- end: forumdisplay_threadlist_sortrating -->
					<option value="replies" >Sort by: Replies</option>
					<option value="views" >Sort by: Views</option>
				</select>
				<select name="order">
					<option value="asc" >Order: Ascending</option>
					<option value="desc" selected="selected">Order: Descending</option>
				</select>
				<select name="datecut">
					<option value="1" >From: Today</option>
					<option value="5" >From: 5 Days Ago</option>
					<option value="10" >From: 10 Days Ago</option>
					<option value="20" >From: 20 Days Ago</option>
					<option value="50" >From: 50 Days Ago</option>
					<option value="75" >From: 75 Days Ago</option>
					<option value="100" >From: 100 Days Ago</option>
					<option value="365" >From: The Last Year</option>
					<option value="9999" >From: The Beginning</option>
				</select>
				<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
			</form>
		</td>
	</tr>
</table>
<div class="float_left">
	<!-- start: multipage -->
<div class="pagination">
<span class="pages">Pages (66):</span>
<!-- start: multipage_prevpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=62" class="pagination_previous">&laquo; Previous</a>
<!-- end: multipage_prevpage --><!-- start: multipage_start -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4" class="pagination_first">1</a>  ...
<!-- end: multipage_start --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=61" class="pagination_page">61</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=62" class="pagination_page">62</a>
<!-- end: multipage_page --><!-- start: multipage_page_current -->
 <span class="pagination_current">63</span>
<!-- end: multipage_page_current --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=64" class="pagination_page">64</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=65" class="pagination_page">65</a>
<!-- end: multipage_page --><!-- start: multipage_end -->
 <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=66" class="pagination_last">66</a>
<!-- end: multipage_end --><!-- start: multipage_nextpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=64" class="pagination_next">Next &raquo;</a>
<!-- end: multipage_nextpage -->
</div>
<!-- end: multipage -->
</div>
<div class="float_right" style="margin-top: 4px;">
	<!-- start: forumdisplay_newthread -->
<a href="https://www.ag-grid.com/forum/newthread.php?fid=4"><img src="https://www.ag-grid.com/forum/images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<br style="clear: both;" />
<br />
<div class="float_left">
	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="https://www.ag-grid.com/forum/images/newfolder.gif" alt="New Posts" title="New Posts" /> New Posts</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/newhotfolder.gif" alt="Hot Thread (New)" title="Hot Thread (New)" /> Hot Thread (New)</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="Hot Thread (No New)" title="Hot Thread (No New)" /> Hot Thread (No New)</dd>
		</dl>
	</div>

	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No New Posts" title="No New Posts" /> No New Posts</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/dot_folder.gif" alt="Contains Posts by You" title="Contains Posts by You" /> Contains Posts by You</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/lockfolder.gif" alt="Locked Thread" title="Locked Thread" /> Locked Thread</dd>
		</dl>
	</div>
	<br style="clear: both" />
</div>

<div class="float_right" style="text-align: right;">
	
	<!-- start: forumdisplay_searchforum -->
<form action="https://www.ag-grid.com/forum/search.php" method="post">
	<span class="smalltext"><strong>Search this Forum:</strong></span>
	<input type="text" class="textbox" name="keywords" /> <!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	<input type="hidden" name="action" value="do_search" />
	<input type="hidden" name="forums" value="4" />
	<input type="hidden" name="postthread" value="1" />
	</form><br />
<!-- end: forumdisplay_searchforum -->
	<!-- start: forumjump_advanced -->
<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
<span class="smalltext"><strong>Forum Jump:</strong></span>
<select name="fid" class="forumjump">
<option value="-1" >Please select one:</option>
<option value="-1">--------------------</option>
<option value="-4">Private Messages</option>
<option value="-3">User Control Panel</option>
<option value="-5">Who's Online</option>
<option value="-2">Search</option>
<option value="-1">Forum Home</option>
<!-- start: forumjump_bit -->
<option value="3" > ag-Grid</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="4" selected="selected">-- ag-Grid Free Forum (not actively monitored by ag-Grid dev)</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="5" >-- ag-Grid Members Forum (only members can post, monitored daily by ag-Grid dev)</option>
<!-- end: forumjump_bit -->
</select>
<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
</form>
<script type="text/javascript">
<!--
	$$('.forumjump').invoke('observe', 'change', function(e)
	{
		var option = this.options[this.selectedIndex].value

		if(option < 0)
		{
			window.location=('https://www.ag-grid.com/forum/forumdisplay.php?fid='+option)
			return
		}

		window.location=('https://www.ag-grid.com/forum/forumdisplay.php?fid='+this.options[this.selectedIndex].value)
	})
//-->
</script>
<!-- end: forumjump_advanced -->
</div>
<br style="clear: both" />
<!-- start: forumdisplay_threadlist_inlineedit_js -->
<script type="text/javascript" src="https://www.ag-grid.com/forum/jscripts/inline_edit.js?ver=1400"></script>
<script type="text/javascript">
<!--
	if(use_xmlhttprequest == "1")
	{
		new inlineEditor("https://www.ag-grid.com/forum/xmlhttp.php?action=edit_subject&amp;my_post_key="+my_post_key, {className: "subject_editable", spinnerImage: "images/spinner.gif", lang_click_edit: "(Click and hold to edit)"});
	}
// -->
</script>
<!-- end: forumdisplay_threadlist_inlineedit_js -->
<!-- end: forumdisplay_threadlist -->
<!-- start: footer -->
			<br />
			<div class="bottommenu">
				<div class="float_right"><!-- start: footer_languageselect -->
<form method="get" action="https://www.ag-grid.com/forum/forumdisplay.php" id="lang_select">
		<input type="hidden" name="fid" value="4" />
<input type="hidden" name="page" value="63" />

		<input type="hidden" name="my_post_key" value="9d9f8e6842db6d8c8a75a10edcf17276" />
		<select name="language" onchange="MyBB.changeLanguage();">
			<optgroup label="Quick Language Select">
				<option value="english" selected="selected">&nbsp;&nbsp;&nbsp;English (American)</option>

			</optgroup>
		</select>
		<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	</form>
<!-- end: footer_languageselect --></div>
				<div>
					<span class="smalltext"><a href="mailto:webmaster@angulargrid.com">Contact Us</a> | <a href="https://www.ag-grid.com/">ag-Grid Forum</a> | <a href="#top">Return to Top</a> | <a href="#content">Return to Content</a> | <a href="https://ag-grid.com/forum/archive/index.php?forum-4.html">Lite (Archive) Mode</a> | <a href="https://ag-grid.com/forum/misc.php?action=syndication">RSS Syndication</a></span>
				</div>
			</div>
			</div>
		<hr class="hidden" />
			<div id="copyright">
				<div id="debug"></div>
				<!-- MyBB is free software developed and maintained by a volunteer community.
					 It would be much appreciated by the MyBB Group if you left the full copyright and "powered by" notice intact,
					 to show your support for MyBB.  If you choose to remove or modify the copyright below,
					 you may be refused support on the MyBB Community Forums.

					 This is free software, support us and we'll support you. -->
Powered By <a href="http://mybb.com/" target="_blank">MyBB</a>, &copy; 2002-2016 <a href="http://mybb.com/" target="_blank">MyBB Group</a>.<br />
				<!-- End powered by -->
				<br />
<br class="clear" />
<!-- The following piece of code allows MyBB to run scheduled tasks. DO NOT REMOVE --><!-- End task image code -->

		</div>
		</div>
<!-- end: footer -->
</body>

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=4&page=63 by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:51:02 GMT -->
</html>
<!-- end: forumdisplay -->