<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><!-- start: forumdisplay -->
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=5&datecut=0&sortby=subject&order=desc by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:50:58 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<title> - ag-Grid Members Forum (only members can post, monitored daily by ag-Grid dev) </title>
<!-- start: headerinclude -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/prototype7321.js?ver=1603"></script>
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/general7321.js?ver=1603"></script>
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/popup_menu0414.js?ver=1600"></script>
<link type="text/css" rel="stylesheet" href="../../ag-grid.com/forum/cache/themes/theme1/global.css" />
<link type="text/css" rel="stylesheet" href="../../ag-grid.com/forum/cache/themes/theme1/star_ratings.css" />

<script type="text/javascript">
<!--
	var cookieDomain = ".ag-grid.com";
	var cookiePath = "index.html";
	var cookiePrefix = "";
	var deleteevent_confirm = "Are you sure you want to delete this event?";
	var removeattach_confirm = "Are you sure you want to remove the selected attachment from this post?";
	var loading_text = 'Loading. <br />Please Wait..';
	var saving_changes = 'Saving changes..';
	var use_xmlhttprequest = "1";
	var my_post_key = "9d9f8e6842db6d8c8a75a10edcf17276";
	var imagepath = "images";
// -->
</script>

<!-- end: headerinclude -->
<!-- start: forumdisplay_rssdiscovery -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads in ag-Grid Members Forum (only members can post, monitored daily by ag-Grid dev) (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php?fid=5" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads in ag-Grid Members Forum (only members can post, monitored daily by ag-Grid dev) (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0&amp;fid=5" />
<!-- end: forumdisplay_rssdiscovery -->
<script type="text/javascript">
<!--
	lang.no_new_posts = "Forum Contains No New Posts";
	lang.click_mark_read = "Click to mark this forum as read";
// -->
</script>
</head>
<body>
<!-- start: header -->
	<div id="container">
		<a name="top" id="top"></a>
		<div id="header">
			<div class="logo"><a href="index-2.html"><img src="../../ag-grid.com/forum/images/logo.gif" alt="" title="" /></a></div>
			<div class="menu">
				<ul>
					<li><a href="search.php"><img src="images/toplinks/search.gif" alt="" title="" />Search</a></li>
					<li><a href="https://ag-grid.com/forum/memberlist.php"><img src="images/toplinks/memberlist.gif" alt="" title="" />Member List</a></li>
					<li><a href="https://ag-grid.com/forum/calendar.php"><img src="images/toplinks/calendar.gif" alt="" title="" />Calendar</a></li>
					<li><a href="https://ag-grid.com/forum/misc.php?action=help"><img src="images/toplinks/help.gif" alt="" title="" />Help</a></li>
				</ul>
			</div>
			<hr class="hidden" />
			<div id="panel">
				<!-- start: header_welcomeblock_guest -->
<script type="text/javascript">
<!--
	lang.username = "Username";
	lang.password = "Password";
	lang.login = "Login";
	lang.lost_password = " &mdash; <a href=\"member9a16.html?action=lostpw\">Lost Password?<\/a>";
	lang.register_url = " &mdash; <a href=\"member0ddc.php?action=register\">Register<\/a>";
	lang.remember_me = "Remember me";
// -->
</script>
<span style="float: right;"><strong>Current time:</strong> 03-17-2016, 07:50 AM</span>
		<span id="quick_login">Hello There, Guest! (<a href="https://ag-grid.com/forum/member.php?action=login" onclick="MyBB.quickLogin(); return false;">Login</a> &mdash; <a href="member0ddc.php?action=register">Register</a>)</span>
<!-- end: header_welcomeblock_guest -->
			</div>
		</div>
		<hr class="hidden" />
		<br class="clear" />
		<div id="content">
			
			
			
			
			
			<!-- start: nav -->

<div class="navigation">
<!-- start: nav_bit -->
<a href="index-2.html"></a><!-- start: nav_sep -->
 / 
<!-- end: nav_sep -->
<!-- end: nav_bit --><!-- start: nav_bit -->
<a href="forumdisplaye15e.html?fid=3">ag-Grid</a>
<!-- end: nav_bit --><!-- start: nav_sep_active -->
 / 
<!-- end: nav_sep_active --><!-- start: nav_bit_active -->
<span class="active">ag-Grid Members Forum (only members can post, monitored daily by ag-Grid dev)</span>
<!-- end: nav_bit_active -->
</div>
<!-- end: nav -->
			<br />

<!-- end: header -->

<!-- start: forumdisplay_usersbrowsing -->
<span class="smalltext">User(s) browsing this forum: 1 Guest(s)</span><br />
<!-- end: forumdisplay_usersbrowsing -->


<!-- start: forumdisplay_threadlist -->
<div class="float_left">
	
</div>
<div class="float_right">
	<!-- start: forumdisplay_newthread -->
<a href="newthread64d9.html?fid=5"><img src="images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<table border="0" cellspacing="1" cellpadding="4" class="tborder" style="clear: both;">
	<tr>
		<td class="thead" colspan="7">
			<div style="float: right;">
				<span class="smalltext"><strong><a href="misc1fe7.html?action=markread&amp;fid=5">Mark this forum read</a> | <a href="usercp2de7b.html?action=addsubscription&amp;type=forum&amp;fid=5&amp;my_post_key=9d9f8e6842db6d8c8a75a10edcf17276">Subscribe to this forum</a></strong></span>
			</div>
			<div>
				<strong>ag-Grid Members Forum (only members can post, monitored daily by ag-Grid dev)</strong>
			</div>
		</td>
	</tr>
	<tr>
		<td class="tcat" colspan="3" width="66%"><span class="smalltext"><strong><a href="forumdisplay01ff.html?fid=5&amp;datecut=0&amp;sortby=subject&amp;order=asc">Thread</a> <!-- start: forumdisplay_orderarrow -->
<span class="smalltext">[<a href="forumdisplay01ff.html?fid=5&amp;datecut=0&amp;sortby=subject&amp;order=asc">asc</a>]</span>
<!-- end: forumdisplay_orderarrow --> / <a href="forumdisplay0878.html?fid=5&amp;datecut=0&amp;sortby=starter&amp;order=asc">Author</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="forumdisplay527d.html?fid=5&amp;datecut=0&amp;sortby=replies&amp;order=desc">Replies</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="forumdisplaye69d.html?fid=5&amp;datecut=0&amp;sortby=views&amp;order=desc">Views</a> </strong></span></td>
		<!-- start: forumdisplay_threadlist_rating -->
	<td class="tcat" align="center" width="80">
		<span class="smalltext"><strong><a href="forumdisplayb5dc.html?fid=5&amp;datecut=0&amp;sortby=rating&amp;order=desc">Rating</a> </strong></span>
		<script type="text/javascript" src="jscripts/rating9348.js?ver=1400"></script>
		<script type="text/javascript">
		<!--
			lang.stars = new Array();
			lang.stars[1] = "1 star out of 5";
			lang.stars[2] = "2 stars out of 5";
			lang.stars[3] = "3 stars out of 5";
			lang.stars[4] = "4 stars out of 5";
			lang.stars[5] = "5 stars out of 5";
		// -->
		</script>
	</td>

<!-- end: forumdisplay_threadlist_rating -->
		<td class="tcat" align="right" width="20%"><span class="smalltext"><strong><a href="forumdisplay7611.html?fid=5&amp;datecut=0&amp;sortby=lastpost&amp;order=desc">Last Post</a> </strong></span></td>
		
	</tr>
	
	
	<!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="showthread5681.html?tid=3566" class=" subject_old" id="tid_3566">rowDeselected stops working</a></span>
			<div class="author smalltext"><a href="member4aa4.php?action=profile&amp;uid=225">SDQ</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3566);">2</a></td>
	<td align="center" class="trow1 forumdisplay_regular">42</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3566">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3566">
			<li style="width: 0%" class="current_rating" id="current_rating_3566">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3566, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">Today 02:17 AM<br />
		<a href="showthread4763.html?tid=3566&amp;action=lastpost">Last Post</a>: <a href="member4aa4.php?action=profile&amp;uid=225">SDQ</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread -->
	<tr>
		<td class="tfoot" align="right" colspan="7">
			<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
				<input type="hidden" name="selectall" value="" />
				<input type="hidden" name="fid" value="5" />
				<select name="sortby">
					<option value="subject" selected="selected">Sort by: Subject</option>
					<option value="lastpost" >Sort by: Last Post</option>
					<option value="starter" >Sort by: Author</option>
					<option value="started" >Sort by: Creation Time</option>
					<!-- start: forumdisplay_threadlist_sortrating -->
<option value="rating" >Sort by: Rating</option>
<!-- end: forumdisplay_threadlist_sortrating -->
					<option value="replies" >Sort by: Replies</option>
					<option value="views" >Sort by: Views</option>
				</select>
				<select name="order">
					<option value="asc" >Order: Ascending</option>
					<option value="desc" selected="selected">Order: Descending</option>
				</select>
				<select name="datecut">
					<option value="1" >From: Today</option>
					<option value="5" >From: 5 Days Ago</option>
					<option value="10" >From: 10 Days Ago</option>
					<option value="20" >From: 20 Days Ago</option>
					<option value="50" >From: 50 Days Ago</option>
					<option value="75" >From: 75 Days Ago</option>
					<option value="100" >From: 100 Days Ago</option>
					<option value="365" >From: The Last Year</option>
					<option value="9999" >From: The Beginning</option>
				</select>
				<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
			</form>
		</td>
	</tr>
</table>
<div class="float_left">
	
</div>
<div class="float_right" style="margin-top: 4px;">
	<!-- start: forumdisplay_newthread -->
<a href="newthread64d9.html?fid=5"><img src="images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<br style="clear: both;" />
<br />
<div class="float_left">
	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="images/newfolder.gif" alt="New Posts" title="New Posts" /> New Posts</dd>
			<dd><img src="images/newhotfolder.gif" alt="Hot Thread (New)" title="Hot Thread (New)" /> Hot Thread (New)</dd>
			<dd><img src="images/hotfolder.gif" alt="Hot Thread (No New)" title="Hot Thread (No New)" /> Hot Thread (No New)</dd>
		</dl>
	</div>

	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="images/folder.gif" alt="No New Posts" title="No New Posts" /> No New Posts</dd>
			<dd><img src="images/dot_folder.gif" alt="Contains Posts by You" title="Contains Posts by You" /> Contains Posts by You</dd>
			<dd><img src="images/lockfolder.gif" alt="Locked Thread" title="Locked Thread" /> Locked Thread</dd>
		</dl>
	</div>
	<br style="clear: both" />
</div>

<div class="float_right" style="text-align: right;">
	
	<!-- start: forumdisplay_searchforum -->
<form action="https://www.ag-grid.com/forum/search.php" method="post">
	<span class="smalltext"><strong>Search this Forum:</strong></span>
	<input type="text" class="textbox" name="keywords" /> <!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	<input type="hidden" name="action" value="do_search" />
	<input type="hidden" name="forums" value="5" />
	<input type="hidden" name="postthread" value="1" />
	</form><br />
<!-- end: forumdisplay_searchforum -->
	<!-- start: forumjump_advanced -->
<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
<span class="smalltext"><strong>Forum Jump:</strong></span>
<select name="fid" class="forumjump">
<option value="-1" >Please select one:</option>
<option value="-1">--------------------</option>
<option value="-4">Private Messages</option>
<option value="-3">User Control Panel</option>
<option value="-5">Who's Online</option>
<option value="-2">Search</option>
<option value="-1">Forum Home</option>
<!-- start: forumjump_bit -->
<option value="3" > ag-Grid</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="4" >-- ag-Grid Free Forum (not actively monitored by ag-Grid dev)</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="5" selected="selected">-- ag-Grid Members Forum (only members can post, monitored daily by ag-Grid dev)</option>
<!-- end: forumjump_bit -->
</select>
<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
</form>
<script type="text/javascript">
<!--
	$$('.forumjump').invoke('observe', 'change', function(e)
	{
		var option = this.options[this.selectedIndex].value

		if(option < 0)
		{
			window.location=('forumdisplay0eb7.html?fid='+option)
			return
		}

		window.location=('forumdisplay0eb7.html?fid='+this.options[this.selectedIndex].value)
	})
//-->
</script>
<!-- end: forumjump_advanced -->
</div>
<br style="clear: both" />
<!-- start: forumdisplay_threadlist_inlineedit_js -->
<script type="text/javascript" src="jscripts/inline_edit9348.js?ver=1400"></script>
<script type="text/javascript">
<!--
	if(use_xmlhttprequest == "1")
	{
		new inlineEditor("xmlhttp3fb2.html?action=edit_subject&amp;my_post_key="+my_post_key, {className: "subject_editable", spinnerImage: "images/spinner.gif", lang_click_edit: "(Click and hold to edit)"});
	}
// -->
</script>
<!-- end: forumdisplay_threadlist_inlineedit_js -->
<!-- end: forumdisplay_threadlist -->
<!-- start: footer -->
			<br />
			<div class="bottommenu">
				<div class="float_right"><!-- start: footer_languageselect -->
<form method="get" action="https://www.ag-grid.com/forum/forumdisplay.php" id="lang_select">
		<input type="hidden" name="fid" value="5" />
<input type="hidden" name="datecut" value="0" />
<input type="hidden" name="sortby" value="subject" />
<input type="hidden" name="order" value="desc" />

		<input type="hidden" name="my_post_key" value="9d9f8e6842db6d8c8a75a10edcf17276" />
		<select name="language" onchange="MyBB.changeLanguage();">
			<optgroup label="Quick Language Select">
				<option value="english" selected="selected">&nbsp;&nbsp;&nbsp;English (American)</option>

			</optgroup>
		</select>
		<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	</form>
<!-- end: footer_languageselect --></div>
				<div>
					<span class="smalltext"><a href="mailto:webmaster@angulargrid.com">Contact Us</a> | <a href="../index.html">ag-Grid Forum</a> | <a href="#top">Return to Top</a> | <a href="#content">Return to Content</a> | <a href="https://ag-grid.com/forum/archive/index.php?forum-5.html">Lite (Archive) Mode</a> | <a href="https://ag-grid.com/forum/misc.php?action=syndication">RSS Syndication</a></span>
				</div>
			</div>
			</div>
		<hr class="hidden" />
			<div id="copyright">
				<div id="debug"></div>
				<!-- MyBB is free software developed and maintained by a volunteer community.
					 It would be much appreciated by the MyBB Group if you left the full copyright and "powered by" notice intact,
					 to show your support for MyBB.  If you choose to remove or modify the copyright below,
					 you may be refused support on the MyBB Community Forums.

					 This is free software, support us and we'll support you. -->
Powered By <a href="http://mybb.com/" target="_blank">MyBB</a>, &copy; 2002-2016 <a href="http://mybb.com/" target="_blank">MyBB Group</a>.<br />
				<!-- End powered by -->
				<br />
<br class="clear" />
<!-- The following piece of code allows MyBB to run scheduled tasks. DO NOT REMOVE --><!-- End task image code -->

		</div>
		</div>
<!-- end: footer -->
</body>

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=5&datecut=0&sortby=subject&order=desc by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:50:58 GMT -->
</html>
<!-- end: forumdisplay -->