<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><!-- start: forumdisplay -->
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=4&page=29 by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:51:44 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<title> - ag-Grid Free Forum (not actively monitored by ag-Grid dev) </title>
<!-- start: headerinclude -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/prototype7321.js?ver=1603"></script>
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/general7321.js?ver=1603"></script>
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/popup_menu0414.js?ver=1600"></script>
<link type="text/css" rel="stylesheet" href="../../ag-grid.com/forum/cache/themes/theme1/global.css" />
<link type="text/css" rel="stylesheet" href="../../ag-grid.com/forum/cache/themes/theme1/star_ratings.css" />

<script type="text/javascript">
<!--
	var cookieDomain = ".ag-grid.com";
	var cookiePath = "index.html";
	var cookiePrefix = "";
	var deleteevent_confirm = "Are you sure you want to delete this event?";
	var removeattach_confirm = "Are you sure you want to remove the selected attachment from this post?";
	var loading_text = 'Loading. <br />Please Wait..';
	var saving_changes = 'Saving changes..';
	var use_xmlhttprequest = "1";
	var my_post_key = "9d9f8e6842db6d8c8a75a10edcf17276";
	var imagepath = "images";
// -->
</script>

<!-- end: headerinclude -->
<!-- start: forumdisplay_rssdiscovery -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads in ag-Grid Free Forum (not actively monitored by ag-Grid dev) (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php?fid=4" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads in ag-Grid Free Forum (not actively monitored by ag-Grid dev) (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0&amp;fid=4" />
<!-- end: forumdisplay_rssdiscovery -->
<script type="text/javascript">
<!--
	lang.no_new_posts = "Forum Contains No New Posts";
	lang.click_mark_read = "Click to mark this forum as read";
// -->
</script>
</head>
<body>
<!-- start: header -->
	<div id="container">
		<a name="top" id="top"></a>
		<div id="header">
			<div class="logo"><a href="index-2.html"><img src="../../ag-grid.com/forum/images/logo.gif" alt="" title="" /></a></div>
			<div class="menu">
				<ul>
					<li><a href="search.php"><img src="images/toplinks/search.gif" alt="" title="" />Search</a></li>
					<li><a href="https://ag-grid.com/forum/memberlist.php"><img src="images/toplinks/memberlist.gif" alt="" title="" />Member List</a></li>
					<li><a href="https://ag-grid.com/forum/calendar.php"><img src="images/toplinks/calendar.gif" alt="" title="" />Calendar</a></li>
					<li><a href="https://ag-grid.com/forum/misc.php?action=help"><img src="images/toplinks/help.gif" alt="" title="" />Help</a></li>
				</ul>
			</div>
			<hr class="hidden" />
			<div id="panel">
				<!-- start: header_welcomeblock_guest -->
<script type="text/javascript">
<!--
	lang.username = "Username";
	lang.password = "Password";
	lang.login = "Login";
	lang.lost_password = " &mdash; <a href=\"member9a16.html?action=lostpw\">Lost Password?<\/a>";
	lang.register_url = " &mdash; <a href=\"member0ddc.php?action=register\">Register<\/a>";
	lang.remember_me = "Remember me";
// -->
</script>
<span style="float: right;"><strong>Current time:</strong> 03-17-2016, 07:51 AM</span>
		<span id="quick_login">Hello There, Guest! (<a href="https://ag-grid.com/forum/member.php?action=login" onclick="MyBB.quickLogin(); return false;">Login</a> &mdash; <a href="member0ddc.php?action=register">Register</a>)</span>
<!-- end: header_welcomeblock_guest -->
			</div>
		</div>
		<hr class="hidden" />
		<br class="clear" />
		<div id="content">
			
			
			
			
			
			<!-- start: nav -->

<div class="navigation">
<!-- start: nav_bit -->
<a href="index-2.html"></a><!-- start: nav_sep -->
 / 
<!-- end: nav_sep -->
<!-- end: nav_bit --><!-- start: nav_bit -->
<a href="forumdisplaye15e.html?fid=3">ag-Grid</a>
<!-- end: nav_bit --><!-- start: nav_sep_active -->
 / 
<!-- end: nav_sep_active --><!-- start: nav_bit_active -->
<span class="active">ag-Grid Free Forum (not actively monitored by ag-Grid dev)</span>
<!-- end: nav_bit_active -->
</div>
<!-- end: nav -->
			<br />

<!-- end: header -->

<!-- start: forumdisplay_usersbrowsing -->
<span class="smalltext">User(s) browsing this forum: 1 Guest(s)</span><br />
<!-- end: forumdisplay_usersbrowsing -->


<!-- start: forumdisplay_threadlist -->
<div class="float_left">
	<!-- start: multipage -->
<div class="pagination">
<span class="pages">Pages (66):</span>
<!-- start: multipage_prevpage -->
<a href="forumdisplay3201.php?fid=4&amp;page=28" class="pagination_previous">&laquo; Previous</a>
<!-- end: multipage_prevpage --><!-- start: multipage_start -->
<a href="forumdisplay6925.html?fid=4" class="pagination_first">1</a>  ...
<!-- end: multipage_start --><!-- start: multipage_page -->
<a href="forumdisplayc6c4.php?fid=4&amp;page=27" class="pagination_page">27</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="forumdisplay3201.php?fid=4&amp;page=28" class="pagination_page">28</a>
<!-- end: multipage_page --><!-- start: multipage_page_current -->
 <span class="pagination_current">29</span>
<!-- end: multipage_page_current --><!-- start: multipage_page -->
<a href="forumdisplay5735.php?fid=4&amp;page=30" class="pagination_page">30</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=31" class="pagination_page">31</a>
<!-- end: multipage_page --><!-- start: multipage_end -->
...  <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=66" class="pagination_last">66</a>
<!-- end: multipage_end --><!-- start: multipage_nextpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=30" class="pagination_next">Next &raquo;</a>
<!-- end: multipage_nextpage -->
</div>
<!-- end: multipage -->
</div>
<div class="float_right">
	<!-- start: forumdisplay_newthread -->
<a href="https://www.ag-grid.com/forum/newthread.php?fid=4"><img src="https://www.ag-grid.com/forum/images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<table border="0" cellspacing="1" cellpadding="4" class="tborder" style="clear: both;">
	<tr>
		<td class="thead" colspan="7">
			<div style="float: right;">
				<span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/misc.php?action=markread&amp;fid=4">Mark this forum read</a> | <a href="https://www.ag-grid.com/forum/usercp2.php?action=addsubscription&amp;type=forum&amp;fid=4&amp;my_post_key=9d9f8e6842db6d8c8a75a10edcf17276">Subscribe to this forum</a></strong></span>
			</div>
			<div>
				<strong>ag-Grid Free Forum (not actively monitored by ag-Grid dev)</strong>
			</div>
		</td>
	</tr>
	<tr>
		<td class="tcat" colspan="3" width="66%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=29&amp;datecut=0&amp;sortby=subject&amp;order=asc">Thread</a>  / <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=29&amp;datecut=0&amp;sortby=starter&amp;order=asc">Author</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=29&amp;datecut=0&amp;sortby=replies&amp;order=desc">Replies</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=29&amp;datecut=0&amp;sortby=views&amp;order=desc">Views</a> </strong></span></td>
		<!-- start: forumdisplay_threadlist_rating -->
	<td class="tcat" align="center" width="80">
		<span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=29&amp;datecut=0&amp;sortby=rating&amp;order=desc">Rating</a> </strong></span>
		<script type="text/javascript" src="https://www.ag-grid.com/forum/jscripts/rating.js?ver=1400"></script>
		<script type="text/javascript">
		<!--
			lang.stars = new Array();
			lang.stars[1] = "1 star out of 5";
			lang.stars[2] = "2 stars out of 5";
			lang.stars[3] = "3 stars out of 5";
			lang.stars[4] = "4 stars out of 5";
			lang.stars[5] = "5 stars out of 5";
		// -->
		</script>
	</td>

<!-- end: forumdisplay_threadlist_rating -->
		<td class="tcat" align="right" width="20%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=29&amp;datecut=0&amp;sortby=lastpost&amp;order=desc">Last Post</a> <!-- start: forumdisplay_orderarrow -->
<span class="smalltext">[<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=29&amp;datecut=0&amp;sortby=lastpost&amp;order=asc">asc</a>]</span>
<!-- end: forumdisplay_orderarrow --></strong></span></td>
		
	</tr>
	
	
	<!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2941" class=" subject_old" id="tid_2941">Change ag-grid id runtime using ng-repeat</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=781">Rushikesh</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2941);">5</a></td>
	<td align="center" class="trow1 forumdisplay_regular">91</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2941">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2941">
			<li style="width: 0%" class="current_rating" id="current_rating_2941">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2941, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-14-2015 03:13 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2941&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2942" class=" subject_old" id="tid_2942">simulate a spreadsheet</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=236">pdemilly</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2942);">3</a></td>
	<td align="center" class="trow2 forumdisplay_regular">100</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2942">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2942">
			<li style="width: 0%" class="current_rating" id="current_rating_2942">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2942, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-14-2015 01:37 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2942&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2940" class=" subject_old" id="tid_2940">Automatic closing of custom filter popup</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=780">martin</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2940);">2</a></td>
	<td align="center" class="trow1 forumdisplay_regular">61</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2940">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2940">
			<li style="width: 0%" class="current_rating" id="current_rating_2940">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2940, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-13-2015 11:24 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2940&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=780">martin</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2938" class=" subject_old" id="tid_2938">Pagination: Page 1 of 0 if grid is empty</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=49">thomas3577</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2938);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">65</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2938">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2938">
			<li style="width: 0%" class="current_rating" id="current_rating_2938">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2938, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-13-2015 09:27 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2938&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2914" class=" subject_old" id="tid_2914">Is row data effectively read only?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=759">DougGrimwade</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2914);">4</a></td>
	<td align="center" class="trow1 forumdisplay_regular">170</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2914">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2914">
			<li style="width: 0%" class="current_rating" id="current_rating_2914">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2914, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-13-2015 07:18 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2914&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=759">DougGrimwade</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2936" class=" subject_old" id="tid_2936">sorting  fields which has both strings and numbers</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=472">kovergal</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2936);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">51</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2936">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2936">
			<li style="width: 0%" class="current_rating" id="current_rating_2936">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2936, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-13-2015 07:14 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2936&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2760" class=" subject_old" id="tid_2760">hide columns</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=624">tubaloth</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2760);">3</a></td>
	<td align="center" class="trow1 forumdisplay_regular">242</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2760">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2760">
			<li style="width: 0%" class="current_rating" id="current_rating_2760">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2760, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-13-2015 06:59 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2760&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2935" class=" subject_old" id="tid_2935">quickFilterText sometime doesn't work</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=432">kim2014</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2935);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">63</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2935">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2935">
			<li style="width: 0%" class="current_rating" id="current_rating_2935">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2935, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-13-2015 06:34 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2935&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2921" class=" subject_old" id="tid_2921">did headerClass stop working?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=607">grid_lover</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2921);">7</a></td>
	<td align="center" class="trow1 forumdisplay_regular">149</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2921">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2921">
			<li style="width: 0%" class="current_rating" id="current_rating_2921">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2921, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-13-2015 07:24 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2921&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2933" class=" subject_old" id="tid_2933">Custom Cell Rendering</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=521">jwalpole</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2933);">3</a></td>
	<td align="center" class="trow2 forumdisplay_regular">212</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2933">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2933">
			<li style="width: 0%" class="current_rating" id="current_rating_2933">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2933, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-13-2015 04:09 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2933&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2917" class=" subject_old" id="tid_2917">Nested Groups</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=734">bongostar44</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2917);">4</a></td>
	<td align="center" class="trow1 forumdisplay_regular">128</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2917">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2917">
			<li style="width: 0%" class="current_rating" id="current_rating_2917">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2917, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-13-2015 01:00 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2917&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=734">bongostar44</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2932" class=" subject_old" id="tid_2932">Moving the cursor back to a particular cell</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=570">kanprasa</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2932);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">46</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2932">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2932">
			<li style="width: 0%" class="current_rating" id="current_rating_2932">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2932, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-12-2015 11:31 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2932&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2836" class=" subject_old" id="tid_2836">ag-grid 2 backward compatible?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=49">thomas3577</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2836);">5</a></td>
	<td align="center" class="trow1 forumdisplay_regular">208</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2836">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2836">
			<li style="width: 0%" class="current_rating" id="current_rating_2836">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2836, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-12-2015 07:27 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2836&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		<!-- start: forumdisplay_thread_attachment_count -->
<div style="float: right;"><img src="https://www.ag-grid.com/forum/images/paperclip.gif" alt="" title="This thread contains 1 attachment." /></div>
<!-- end: forumdisplay_thread_attachment_count -->
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2912" class=" subject_old" id="tid_2912">Problem with edit</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=503">amirox</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2912);">2</a></td>
	<td align="center" class="trow2 forumdisplay_regular">122</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2912">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2912">
			<li style="width: 0%" class="current_rating" id="current_rating_2912">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2912, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-12-2015 06:25 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2912&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2569" class=" subject_old" id="tid_2569">global settings</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=331">shemesh</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2569);">5</a></td>
	<td align="center" class="trow1 forumdisplay_regular">281</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2569">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2569">
			<li style="width: 0%" class="current_rating" id="current_rating_2569">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2569, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-12-2015 06:11 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2569&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2920" class=" subject_old" id="tid_2920">Custom filter creation for angulr grid version 1</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=758">aswinthunchathu</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2920);">4</a></td>
	<td align="center" class="trow2 forumdisplay_regular">99</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2920">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2920">
			<li style="width: 0%" class="current_rating" id="current_rating_2920">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2920, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-12-2015 06:08 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2920&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2929" class=" subject_old" id="tid_2929">can icons be changed with css?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=331">shemesh</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2929);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">63</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2929">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2929">
			<li style="width: 0%" class="current_rating" id="current_rating_2929">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2929, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-12-2015 02:13 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2929&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2927" class=" subject_old" id="tid_2927">can a group row renderer</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=607">grid_lover</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2927);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">87</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2927">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2927">
			<li style="width: 0%" class="current_rating" id="current_rating_2927">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2927, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-11-2015 07:45 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2927&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2926" class=" subject_old" id="tid_2926">Totaling Rows</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=697">sri</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2926);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">101</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2926">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2926">
			<li style="width: 0%" class="current_rating" id="current_rating_2926">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2926, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-11-2015 07:37 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2926&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2924" class=" subject_old" id="tid_2924">Dates</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=697">sri</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2924);">2</a></td>
	<td align="center" class="trow2 forumdisplay_regular">102</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2924">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2924">
			<li style="width: 0%" class="current_rating" id="current_rating_2924">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2924, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-11-2015 07:35 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2924&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread -->
	<tr>
		<td class="tfoot" align="right" colspan="7">
			<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
				<input type="hidden" name="selectall" value="" />
				<input type="hidden" name="fid" value="4" />
				<select name="sortby">
					<option value="subject" >Sort by: Subject</option>
					<option value="lastpost" selected="selected">Sort by: Last Post</option>
					<option value="starter" >Sort by: Author</option>
					<option value="started" >Sort by: Creation Time</option>
					<!-- start: forumdisplay_threadlist_sortrating -->
<option value="rating" >Sort by: Rating</option>
<!-- end: forumdisplay_threadlist_sortrating -->
					<option value="replies" >Sort by: Replies</option>
					<option value="views" >Sort by: Views</option>
				</select>
				<select name="order">
					<option value="asc" >Order: Ascending</option>
					<option value="desc" selected="selected">Order: Descending</option>
				</select>
				<select name="datecut">
					<option value="1" >From: Today</option>
					<option value="5" >From: 5 Days Ago</option>
					<option value="10" >From: 10 Days Ago</option>
					<option value="20" >From: 20 Days Ago</option>
					<option value="50" >From: 50 Days Ago</option>
					<option value="75" >From: 75 Days Ago</option>
					<option value="100" >From: 100 Days Ago</option>
					<option value="365" >From: The Last Year</option>
					<option value="9999" >From: The Beginning</option>
				</select>
				<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
			</form>
		</td>
	</tr>
</table>
<div class="float_left">
	<!-- start: multipage -->
<div class="pagination">
<span class="pages">Pages (66):</span>
<!-- start: multipage_prevpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=28" class="pagination_previous">&laquo; Previous</a>
<!-- end: multipage_prevpage --><!-- start: multipage_start -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4" class="pagination_first">1</a>  ...
<!-- end: multipage_start --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=27" class="pagination_page">27</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=28" class="pagination_page">28</a>
<!-- end: multipage_page --><!-- start: multipage_page_current -->
 <span class="pagination_current">29</span>
<!-- end: multipage_page_current --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=30" class="pagination_page">30</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=31" class="pagination_page">31</a>
<!-- end: multipage_page --><!-- start: multipage_end -->
...  <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=66" class="pagination_last">66</a>
<!-- end: multipage_end --><!-- start: multipage_nextpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=30" class="pagination_next">Next &raquo;</a>
<!-- end: multipage_nextpage -->
</div>
<!-- end: multipage -->
</div>
<div class="float_right" style="margin-top: 4px;">
	<!-- start: forumdisplay_newthread -->
<a href="https://www.ag-grid.com/forum/newthread.php?fid=4"><img src="https://www.ag-grid.com/forum/images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<br style="clear: both;" />
<br />
<div class="float_left">
	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="https://www.ag-grid.com/forum/images/newfolder.gif" alt="New Posts" title="New Posts" /> New Posts</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/newhotfolder.gif" alt="Hot Thread (New)" title="Hot Thread (New)" /> Hot Thread (New)</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="Hot Thread (No New)" title="Hot Thread (No New)" /> Hot Thread (No New)</dd>
		</dl>
	</div>

	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No New Posts" title="No New Posts" /> No New Posts</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/dot_folder.gif" alt="Contains Posts by You" title="Contains Posts by You" /> Contains Posts by You</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/lockfolder.gif" alt="Locked Thread" title="Locked Thread" /> Locked Thread</dd>
		</dl>
	</div>
	<br style="clear: both" />
</div>

<div class="float_right" style="text-align: right;">
	
	<!-- start: forumdisplay_searchforum -->
<form action="https://www.ag-grid.com/forum/search.php" method="post">
	<span class="smalltext"><strong>Search this Forum:</strong></span>
	<input type="text" class="textbox" name="keywords" /> <!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	<input type="hidden" name="action" value="do_search" />
	<input type="hidden" name="forums" value="4" />
	<input type="hidden" name="postthread" value="1" />
	</form><br />
<!-- end: forumdisplay_searchforum -->
	<!-- start: forumjump_advanced -->
<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
<span class="smalltext"><strong>Forum Jump:</strong></span>
<select name="fid" class="forumjump">
<option value="-1" >Please select one:</option>
<option value="-1">--------------------</option>
<option value="-4">Private Messages</option>
<option value="-3">User Control Panel</option>
<option value="-5">Who's Online</option>
<option value="-2">Search</option>
<option value="-1">Forum Home</option>
<!-- start: forumjump_bit -->
<option value="3" > ag-Grid</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="4" selected="selected">-- ag-Grid Free Forum (not actively monitored by ag-Grid dev)</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="5" >-- ag-Grid Members Forum (only members can post, monitored daily by ag-Grid dev)</option>
<!-- end: forumjump_bit -->
</select>
<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
</form>
<script type="text/javascript">
<!--
	$$('.forumjump').invoke('observe', 'change', function(e)
	{
		var option = this.options[this.selectedIndex].value

		if(option < 0)
		{
			window.location=('https://www.ag-grid.com/forum/forumdisplay.php?fid='+option)
			return
		}

		window.location=('https://www.ag-grid.com/forum/forumdisplay.php?fid='+this.options[this.selectedIndex].value)
	})
//-->
</script>
<!-- end: forumjump_advanced -->
</div>
<br style="clear: both" />
<!-- start: forumdisplay_threadlist_inlineedit_js -->
<script type="text/javascript" src="https://www.ag-grid.com/forum/jscripts/inline_edit.js?ver=1400"></script>
<script type="text/javascript">
<!--
	if(use_xmlhttprequest == "1")
	{
		new inlineEditor("https://www.ag-grid.com/forum/xmlhttp.php?action=edit_subject&amp;my_post_key="+my_post_key, {className: "subject_editable", spinnerImage: "images/spinner.gif", lang_click_edit: "(Click and hold to edit)"});
	}
// -->
</script>
<!-- end: forumdisplay_threadlist_inlineedit_js -->
<!-- end: forumdisplay_threadlist -->
<!-- start: footer -->
			<br />
			<div class="bottommenu">
				<div class="float_right"><!-- start: footer_languageselect -->
<form method="get" action="https://www.ag-grid.com/forum/forumdisplay.php" id="lang_select">
		<input type="hidden" name="fid" value="4" />
<input type="hidden" name="page" value="29" />

		<input type="hidden" name="my_post_key" value="9d9f8e6842db6d8c8a75a10edcf17276" />
		<select name="language" onchange="MyBB.changeLanguage();">
			<optgroup label="Quick Language Select">
				<option value="english" selected="selected">&nbsp;&nbsp;&nbsp;English (American)</option>

			</optgroup>
		</select>
		<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	</form>
<!-- end: footer_languageselect --></div>
				<div>
					<span class="smalltext"><a href="mailto:webmaster@angulargrid.com">Contact Us</a> | <a href="https://www.ag-grid.com/">ag-Grid Forum</a> | <a href="#top">Return to Top</a> | <a href="#content">Return to Content</a> | <a href="https://ag-grid.com/forum/archive/index.php?forum-4.html">Lite (Archive) Mode</a> | <a href="https://ag-grid.com/forum/misc.php?action=syndication">RSS Syndication</a></span>
				</div>
			</div>
			</div>
		<hr class="hidden" />
			<div id="copyright">
				<div id="debug"></div>
				<!-- MyBB is free software developed and maintained by a volunteer community.
					 It would be much appreciated by the MyBB Group if you left the full copyright and "powered by" notice intact,
					 to show your support for MyBB.  If you choose to remove or modify the copyright below,
					 you may be refused support on the MyBB Community Forums.

					 This is free software, support us and we'll support you. -->
Powered By <a href="http://mybb.com/" target="_blank">MyBB</a>, &copy; 2002-2016 <a href="http://mybb.com/" target="_blank">MyBB Group</a>.<br />
				<!-- End powered by -->
				<br />
<br class="clear" />
<!-- The following piece of code allows MyBB to run scheduled tasks. DO NOT REMOVE --><!-- End task image code -->

		</div>
		</div>
<!-- end: footer -->
</body>

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=4&page=29 by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:51:44 GMT -->
</html>
<!-- end: forumdisplay -->