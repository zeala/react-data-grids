<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><!-- start: forumdisplay -->
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=4&page=55 by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:51:00 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<title> - ag-Grid Free Forum (not actively monitored by ag-Grid dev) </title>
<!-- start: headerinclude -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<script type="text/javascript" src="https://ag-grid.com/forum/jscripts/prototype.js?ver=1603"></script>
<script type="text/javascript" src="https://ag-grid.com/forum/jscripts/general.js?ver=1603"></script>
<script type="text/javascript" src="https://ag-grid.com/forum/jscripts/popup_menu.js?ver=1600"></script>
<link type="text/css" rel="stylesheet" href="https://ag-grid.com/forum/cache/themes/theme1/global.css" />
<link type="text/css" rel="stylesheet" href="https://ag-grid.com/forum/cache/themes/theme1/star_ratings.css" />

<script type="text/javascript">
<!--
	var cookieDomain = ".ag-grid.com";
	var cookiePath = "https://www.ag-grid.com/forum/";
	var cookiePrefix = "";
	var deleteevent_confirm = "Are you sure you want to delete this event?";
	var removeattach_confirm = "Are you sure you want to remove the selected attachment from this post?";
	var loading_text = 'Loading. <br />Please Wait..';
	var saving_changes = 'Saving changes..';
	var use_xmlhttprequest = "1";
	var my_post_key = "9d9f8e6842db6d8c8a75a10edcf17276";
	var imagepath = "images";
// -->
</script>

<!-- end: headerinclude -->
<!-- start: forumdisplay_rssdiscovery -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads in ag-Grid Free Forum (not actively monitored by ag-Grid dev) (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php?fid=4" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads in ag-Grid Free Forum (not actively monitored by ag-Grid dev) (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0&amp;fid=4" />
<!-- end: forumdisplay_rssdiscovery -->
<script type="text/javascript">
<!--
	lang.no_new_posts = "Forum Contains No New Posts";
	lang.click_mark_read = "Click to mark this forum as read";
// -->
</script>
</head>
<body>
<!-- start: header -->
	<div id="container">
		<a name="top" id="top"></a>
		<div id="header">
			<div class="logo"><a href="https://ag-grid.com/forum/index.php"><img src="https://ag-grid.com/forum/images/logo.gif" alt="" title="" /></a></div>
			<div class="menu">
				<ul>
					<li><a href="https://ag-grid.com/forum/search.php"><img src="https://www.ag-grid.com/forum/images/toplinks/search.gif" alt="" title="" />Search</a></li>
					<li><a href="https://ag-grid.com/forum/memberlist.php"><img src="https://www.ag-grid.com/forum/images/toplinks/memberlist.gif" alt="" title="" />Member List</a></li>
					<li><a href="https://ag-grid.com/forum/calendar.php"><img src="https://www.ag-grid.com/forum/images/toplinks/calendar.gif" alt="" title="" />Calendar</a></li>
					<li><a href="https://ag-grid.com/forum/misc.php?action=help"><img src="https://www.ag-grid.com/forum/images/toplinks/help.gif" alt="" title="" />Help</a></li>
				</ul>
			</div>
			<hr class="hidden" />
			<div id="panel">
				<!-- start: header_welcomeblock_guest -->
<script type="text/javascript">
<!--
	lang.username = "Username";
	lang.password = "Password";
	lang.login = "Login";
	lang.lost_password = " &mdash; <a href=\"https://ag-grid.com/forum/member.php?action=lostpw\">Lost Password?<\/a>";
	lang.register_url = " &mdash; <a href=\"https://ag-grid.com/forum/member.php?action=register\">Register<\/a>";
	lang.remember_me = "Remember me";
// -->
</script>
<span style="float: right;"><strong>Current time:</strong> 03-17-2016, 07:50 AM</span>
		<span id="quick_login">Hello There, Guest! (<a href="https://ag-grid.com/forum/member.php?action=login" onclick="MyBB.quickLogin(); return false;">Login</a> &mdash; <a href="https://ag-grid.com/forum/member.php?action=register">Register</a>)</span>
<!-- end: header_welcomeblock_guest -->
			</div>
		</div>
		<hr class="hidden" />
		<br class="clear" />
		<div id="content">
			
			
			
			
			
			<!-- start: nav -->

<div class="navigation">
<!-- start: nav_bit -->
<a href="https://ag-grid.com/forum/index.php"></a><!-- start: nav_sep -->
 / 
<!-- end: nav_sep -->
<!-- end: nav_bit --><!-- start: nav_bit -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=3">ag-Grid</a>
<!-- end: nav_bit --><!-- start: nav_sep_active -->
 / 
<!-- end: nav_sep_active --><!-- start: nav_bit_active -->
<span class="active">ag-Grid Free Forum (not actively monitored by ag-Grid dev)</span>
<!-- end: nav_bit_active -->
</div>
<!-- end: nav -->
			<br />

<!-- end: header -->

<!-- start: forumdisplay_usersbrowsing -->
<span class="smalltext">User(s) browsing this forum: 1 Guest(s)</span><br />
<!-- end: forumdisplay_usersbrowsing -->


<!-- start: forumdisplay_threadlist -->
<div class="float_left">
	<!-- start: multipage -->
<div class="pagination">
<span class="pages">Pages (66):</span>
<!-- start: multipage_prevpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=54" class="pagination_previous">&laquo; Previous</a>
<!-- end: multipage_prevpage --><!-- start: multipage_start -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4" class="pagination_first">1</a>  ...
<!-- end: multipage_start --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=53" class="pagination_page">53</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=54" class="pagination_page">54</a>
<!-- end: multipage_page --><!-- start: multipage_page_current -->
 <span class="pagination_current">55</span>
<!-- end: multipage_page_current --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=56" class="pagination_page">56</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=57" class="pagination_page">57</a>
<!-- end: multipage_page --><!-- start: multipage_end -->
...  <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=66" class="pagination_last">66</a>
<!-- end: multipage_end --><!-- start: multipage_nextpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=56" class="pagination_next">Next &raquo;</a>
<!-- end: multipage_nextpage -->
</div>
<!-- end: multipage -->
</div>
<div class="float_right">
	<!-- start: forumdisplay_newthread -->
<a href="https://www.ag-grid.com/forum/newthread.php?fid=4"><img src="https://www.ag-grid.com/forum/images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<table border="0" cellspacing="1" cellpadding="4" class="tborder" style="clear: both;">
	<tr>
		<td class="thead" colspan="7">
			<div style="float: right;">
				<span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/misc.php?action=markread&amp;fid=4">Mark this forum read</a> | <a href="https://www.ag-grid.com/forum/usercp2.php?action=addsubscription&amp;type=forum&amp;fid=4&amp;my_post_key=9d9f8e6842db6d8c8a75a10edcf17276">Subscribe to this forum</a></strong></span>
			</div>
			<div>
				<strong>ag-Grid Free Forum (not actively monitored by ag-Grid dev)</strong>
			</div>
		</td>
	</tr>
	<tr>
		<td class="tcat" colspan="3" width="66%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=55&amp;datecut=0&amp;sortby=subject&amp;order=asc">Thread</a>  / <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=55&amp;datecut=0&amp;sortby=starter&amp;order=asc">Author</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=55&amp;datecut=0&amp;sortby=replies&amp;order=desc">Replies</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=55&amp;datecut=0&amp;sortby=views&amp;order=desc">Views</a> </strong></span></td>
		<!-- start: forumdisplay_threadlist_rating -->
	<td class="tcat" align="center" width="80">
		<span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=55&amp;datecut=0&amp;sortby=rating&amp;order=desc">Rating</a> </strong></span>
		<script type="text/javascript" src="https://www.ag-grid.com/forum/jscripts/rating.js?ver=1400"></script>
		<script type="text/javascript">
		<!--
			lang.stars = new Array();
			lang.stars[1] = "1 star out of 5";
			lang.stars[2] = "2 stars out of 5";
			lang.stars[3] = "3 stars out of 5";
			lang.stars[4] = "4 stars out of 5";
			lang.stars[5] = "5 stars out of 5";
		// -->
		</script>
	</td>

<!-- end: forumdisplay_threadlist_rating -->
		<td class="tcat" align="right" width="20%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=55&amp;datecut=0&amp;sortby=lastpost&amp;order=desc">Last Post</a> <!-- start: forumdisplay_orderarrow -->
<span class="smalltext">[<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=55&amp;datecut=0&amp;sortby=lastpost&amp;order=asc">asc</a>]</span>
<!-- end: forumdisplay_orderarrow --></strong></span></td>
		
	</tr>
	
	
	<!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2411" class=" subject_old" id="tid_2411">Defining min-width for api.sizeColumnsToFit</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=225">SDQ</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2411);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">257</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2411">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2411">
			<li style="width: 0%" class="current_rating" id="current_rating_2411">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2411, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">07-01-2015 08:16 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2411&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2410" class=" subject_old" id="tid_2410">Column visibility and updating pinned column count</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=212">son</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2410);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">248</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2410">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2410">
			<li style="width: 0%" class="current_rating" id="current_rating_2410">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2410, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">07-01-2015 07:37 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2410&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2386" class=" subject_old" id="tid_2386">Grid not initializing</a><!-- start: forumdisplay_thread_multipage -->
 <span class="smalltext">(Pages: <!-- start: forumdisplay_thread_multipage_page -->
<a href="https://www.ag-grid.com/forum/showthread.php?tid=2386">1</a> 
<!-- end: forumdisplay_thread_multipage_page --><!-- start: forumdisplay_thread_multipage_page -->
<a href="https://www.ag-grid.com/forum/showthread.php?tid=2386&amp;page=2">2</a> 
<!-- end: forumdisplay_thread_multipage_page -->)</span>
<!-- end: forumdisplay_thread_multipage --></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=323">pad2020</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2386);">18</a></td>
	<td align="center" class="trow1 forumdisplay_regular">2,332</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2386">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2386">
			<li style="width: 0%" class="current_rating" id="current_rating_2386">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2386, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">07-01-2015 01:54 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2386&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/icons/lightbulb.gif" alt="Lightbulb" /></td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=11" class=" subject_old" id="tid_11">Save/Restore the current state of column width, order, etc?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=19">beernutz</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(11);">4</a></td>
	<td align="center" class="trow2 forumdisplay_regular">908</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_11">
		<ul class="star_rating star_rating_notrated" id="rating_thread_11">
			<li style="width: 100%" class="current_rating" id="current_rating_11">1 Vote(s) - 5 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(11, { width: '100', extra_class: ' star_rating_notrated', current_average: '1 Vote(s) - 5 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-30-2015 06:19 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=11&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/icons/question.gif" alt="Question" /></td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2407" class=" subject_old" id="tid_2407">Hide Column in Group</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=10">jgravois</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2407);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">223</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2407">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2407">
			<li style="width: 0%" class="current_rating" id="current_rating_2407">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2407, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-30-2015 06:17 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2407&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2349" class=" subject_old" id="tid_2349">1.9.2 to 1.10.0</a><!-- start: forumdisplay_thread_multipage -->
 <span class="smalltext">(Pages: <!-- start: forumdisplay_thread_multipage_page -->
<a href="https://www.ag-grid.com/forum/showthread.php?tid=2349">1</a> 
<!-- end: forumdisplay_thread_multipage_page --><!-- start: forumdisplay_thread_multipage_page -->
<a href="https://www.ag-grid.com/forum/showthread.php?tid=2349&amp;page=2">2</a> 
<!-- end: forumdisplay_thread_multipage_page --><!-- start: forumdisplay_thread_multipage_page -->
<a href="https://www.ag-grid.com/forum/showthread.php?tid=2349&amp;page=3">3</a> 
<!-- end: forumdisplay_thread_multipage_page --><!-- start: forumdisplay_thread_multipage_page -->
<a href="https://www.ag-grid.com/forum/showthread.php?tid=2349&amp;page=4">4</a> 
<!-- end: forumdisplay_thread_multipage_page -->)</span>
<!-- end: forumdisplay_thread_multipage --></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=275">asqan</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2349);">37</a></td>
	<td align="center" class="trow2 forumdisplay_regular">3,342</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2349">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2349">
			<li style="width: 0%" class="current_rating" id="current_rating_2349">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2349, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-30-2015 04:50 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2349&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2405" class=" subject_old" id="tid_2405">Module 'angularGrid' is not available</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=299">arnoldmq</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2405);">2</a></td>
	<td align="center" class="trow1 forumdisplay_regular">397</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2405">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2405">
			<li style="width: 0%" class="current_rating" id="current_rating_2405">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2405, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-30-2015 12:19 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2405&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=299">arnoldmq</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2404" class=" subject_old" id="tid_2404">Custom Template for Group Row</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=333">ammarkhan91</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2404);">8</a></td>
	<td align="center" class="trow2 forumdisplay_regular">632</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2404">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2404">
			<li style="width: 0%" class="current_rating" id="current_rating_2404">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2404, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-29-2015 11:40 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2404&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=333">ammarkhan91</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2381" class=" subject_old" id="tid_2381">reloading filter gui</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=320">fordPrefect</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2381);">8</a></td>
	<td align="center" class="trow1 forumdisplay_regular">602</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2381">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2381">
			<li style="width: 0%" class="current_rating" id="current_rating_2381">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2381, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-29-2015 10:45 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2381&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2401" class=" subject_old" id="tid_2401">Slow when scrolling</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=5">UrvishNZ</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2401);">5</a></td>
	<td align="center" class="trow2 forumdisplay_regular">593</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2401">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2401">
			<li style="width: 0%" class="current_rating" id="current_rating_2401">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2401, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-29-2015 05:33 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2401&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=6">DipakMV</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		<!-- start: forumdisplay_thread_attachment_count -->
<div style="float: right;"><img src="https://www.ag-grid.com/forum/images/paperclip.gif" alt="" title="This thread contains 1 attachment." /></div>
<!-- end: forumdisplay_thread_attachment_count -->
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2378" class=" subject_old" id="tid_2378">Change Angulargrid  Version</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=5">UrvishNZ</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2378);">5</a></td>
	<td align="center" class="trow1 forumdisplay_regular">772</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2378">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2378">
			<li style="width: 0%" class="current_rating" id="current_rating_2378">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2378, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-29-2015 05:26 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2378&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2397" class=" subject_old" id="tid_2397">expanding grid row</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=329">jesse</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2397);">5</a></td>
	<td align="center" class="trow2 forumdisplay_regular">512</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2397">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2397">
			<li style="width: 0%" class="current_rating" id="current_rating_2397">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2397, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-29-2015 05:24 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2397&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2394" class=" subject_old" id="tid_2394">NEWSFLASH!!! I'm speaking at Angular Connect London</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2394);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">411</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2394">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2394">
			<li style="width: 100%" class="current_rating" id="current_rating_2394">2 Vote(s) - 5 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2394, { width: '100', extra_class: ' star_rating_notrated', current_average: '2 Vote(s) - 5 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-29-2015 03:02 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2394&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=275">asqan</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2399" class=" subject_old" id="tid_2399">Sort Filter Inactive Icon</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=225">SDQ</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2399);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">251</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2399">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2399">
			<li style="width: 0%" class="current_rating" id="current_rating_2399">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2399, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-27-2015 05:25 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2399&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2395" class=" subject_old" id="tid_2395">Replacing contents in columns when filter is applied</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=324">millionhari</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2395);">3</a></td>
	<td align="center" class="trow1 forumdisplay_regular">349</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2395">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2395">
			<li style="width: 0%" class="current_rating" id="current_rating_2395">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2395, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-27-2015 05:24 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2395&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2400" class=" subject_old" id="tid_2400">It is possible to customize the filter without opening dialog?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=244">jefferson.araujo</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2400);">0</a></td>
	<td align="center" class="trow2 forumdisplay_regular">175</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2400">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2400">
			<li style="width: 0%" class="current_rating" id="current_rating_2400">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2400, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-27-2015 09:13 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2400&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=244">jefferson.araujo</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2388" class=" subject_old" id="tid_2388">AngularJS variables not registering after AngularGrid Initialization</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=325">sdwinder</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2388);">7</a></td>
	<td align="center" class="trow1 forumdisplay_regular">906</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2388">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2388">
			<li style="width: 0%" class="current_rating" id="current_rating_2388">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2388, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-27-2015 03:23 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2388&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2393" class=" subject_old" id="tid_2393">Server-side filtering</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=258">gambcl</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2393);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">267</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2393">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2393">
			<li style="width: 0%" class="current_rating" id="current_rating_2393">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2393, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-27-2015 02:43 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2393&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/icons/question.gif" alt="Question" /></td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2392" class=" subject_old" id="tid_2392">Filter text being lower-cased</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=258">gambcl</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2392);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">223</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2392">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2392">
			<li style="width: 0%" class="current_rating" id="current_rating_2392">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2392, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-27-2015 02:38 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2392&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2384" class=" subject_old" id="tid_2384">dontUseScrolls is required to be set to true for my grid to display</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=322">chandramuralis</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2384);">4</a></td>
	<td align="center" class="trow2 forumdisplay_regular">646</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2384">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2384">
			<li style="width: 0%" class="current_rating" id="current_rating_2384">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2384, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-27-2015 12:52 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2384&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=322">chandramuralis</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread -->
	<tr>
		<td class="tfoot" align="right" colspan="7">
			<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
				<input type="hidden" name="selectall" value="" />
				<input type="hidden" name="fid" value="4" />
				<select name="sortby">
					<option value="subject" >Sort by: Subject</option>
					<option value="lastpost" selected="selected">Sort by: Last Post</option>
					<option value="starter" >Sort by: Author</option>
					<option value="started" >Sort by: Creation Time</option>
					<!-- start: forumdisplay_threadlist_sortrating -->
<option value="rating" >Sort by: Rating</option>
<!-- end: forumdisplay_threadlist_sortrating -->
					<option value="replies" >Sort by: Replies</option>
					<option value="views" >Sort by: Views</option>
				</select>
				<select name="order">
					<option value="asc" >Order: Ascending</option>
					<option value="desc" selected="selected">Order: Descending</option>
				</select>
				<select name="datecut">
					<option value="1" >From: Today</option>
					<option value="5" >From: 5 Days Ago</option>
					<option value="10" >From: 10 Days Ago</option>
					<option value="20" >From: 20 Days Ago</option>
					<option value="50" >From: 50 Days Ago</option>
					<option value="75" >From: 75 Days Ago</option>
					<option value="100" >From: 100 Days Ago</option>
					<option value="365" >From: The Last Year</option>
					<option value="9999" >From: The Beginning</option>
				</select>
				<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
			</form>
		</td>
	</tr>
</table>
<div class="float_left">
	<!-- start: multipage -->
<div class="pagination">
<span class="pages">Pages (66):</span>
<!-- start: multipage_prevpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=54" class="pagination_previous">&laquo; Previous</a>
<!-- end: multipage_prevpage --><!-- start: multipage_start -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4" class="pagination_first">1</a>  ...
<!-- end: multipage_start --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=53" class="pagination_page">53</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=54" class="pagination_page">54</a>
<!-- end: multipage_page --><!-- start: multipage_page_current -->
 <span class="pagination_current">55</span>
<!-- end: multipage_page_current --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=56" class="pagination_page">56</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=57" class="pagination_page">57</a>
<!-- end: multipage_page --><!-- start: multipage_end -->
...  <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=66" class="pagination_last">66</a>
<!-- end: multipage_end --><!-- start: multipage_nextpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=56" class="pagination_next">Next &raquo;</a>
<!-- end: multipage_nextpage -->
</div>
<!-- end: multipage -->
</div>
<div class="float_right" style="margin-top: 4px;">
	<!-- start: forumdisplay_newthread -->
<a href="https://www.ag-grid.com/forum/newthread.php?fid=4"><img src="https://www.ag-grid.com/forum/images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<br style="clear: both;" />
<br />
<div class="float_left">
	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="https://www.ag-grid.com/forum/images/newfolder.gif" alt="New Posts" title="New Posts" /> New Posts</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/newhotfolder.gif" alt="Hot Thread (New)" title="Hot Thread (New)" /> Hot Thread (New)</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="Hot Thread (No New)" title="Hot Thread (No New)" /> Hot Thread (No New)</dd>
		</dl>
	</div>

	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No New Posts" title="No New Posts" /> No New Posts</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/dot_folder.gif" alt="Contains Posts by You" title="Contains Posts by You" /> Contains Posts by You</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/lockfolder.gif" alt="Locked Thread" title="Locked Thread" /> Locked Thread</dd>
		</dl>
	</div>
	<br style="clear: both" />
</div>

<div class="float_right" style="text-align: right;">
	
	<!-- start: forumdisplay_searchforum -->
<form action="https://www.ag-grid.com/forum/search.php" method="post">
	<span class="smalltext"><strong>Search this Forum:</strong></span>
	<input type="text" class="textbox" name="keywords" /> <!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	<input type="hidden" name="action" value="do_search" />
	<input type="hidden" name="forums" value="4" />
	<input type="hidden" name="postthread" value="1" />
	</form><br />
<!-- end: forumdisplay_searchforum -->
	<!-- start: forumjump_advanced -->
<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
<span class="smalltext"><strong>Forum Jump:</strong></span>
<select name="fid" class="forumjump">
<option value="-1" >Please select one:</option>
<option value="-1">--------------------</option>
<option value="-4">Private Messages</option>
<option value="-3">User Control Panel</option>
<option value="-5">Who's Online</option>
<option value="-2">Search</option>
<option value="-1">Forum Home</option>
<!-- start: forumjump_bit -->
<option value="3" > ag-Grid</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="4" selected="selected">-- ag-Grid Free Forum (not actively monitored by ag-Grid dev)</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="5" >-- ag-Grid Members Forum (only members can post, monitored daily by ag-Grid dev)</option>
<!-- end: forumjump_bit -->
</select>
<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
</form>
<script type="text/javascript">
<!--
	$$('.forumjump').invoke('observe', 'change', function(e)
	{
		var option = this.options[this.selectedIndex].value

		if(option < 0)
		{
			window.location=('https://www.ag-grid.com/forum/forumdisplay.php?fid='+option)
			return
		}

		window.location=('https://www.ag-grid.com/forum/forumdisplay.php?fid='+this.options[this.selectedIndex].value)
	})
//-->
</script>
<!-- end: forumjump_advanced -->
</div>
<br style="clear: both" />
<!-- start: forumdisplay_threadlist_inlineedit_js -->
<script type="text/javascript" src="https://www.ag-grid.com/forum/jscripts/inline_edit.js?ver=1400"></script>
<script type="text/javascript">
<!--
	if(use_xmlhttprequest == "1")
	{
		new inlineEditor("https://www.ag-grid.com/forum/xmlhttp.php?action=edit_subject&amp;my_post_key="+my_post_key, {className: "subject_editable", spinnerImage: "images/spinner.gif", lang_click_edit: "(Click and hold to edit)"});
	}
// -->
</script>
<!-- end: forumdisplay_threadlist_inlineedit_js -->
<!-- end: forumdisplay_threadlist -->
<!-- start: footer -->
			<br />
			<div class="bottommenu">
				<div class="float_right"><!-- start: footer_languageselect -->
<form method="get" action="https://www.ag-grid.com/forum/forumdisplay.php" id="lang_select">
		<input type="hidden" name="fid" value="4" />
<input type="hidden" name="page" value="55" />

		<input type="hidden" name="my_post_key" value="9d9f8e6842db6d8c8a75a10edcf17276" />
		<select name="language" onchange="MyBB.changeLanguage();">
			<optgroup label="Quick Language Select">
				<option value="english" selected="selected">&nbsp;&nbsp;&nbsp;English (American)</option>

			</optgroup>
		</select>
		<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	</form>
<!-- end: footer_languageselect --></div>
				<div>
					<span class="smalltext"><a href="mailto:webmaster@angulargrid.com">Contact Us</a> | <a href="https://www.ag-grid.com/">ag-Grid Forum</a> | <a href="#top">Return to Top</a> | <a href="#content">Return to Content</a> | <a href="https://ag-grid.com/forum/archive/index.php?forum-4.html">Lite (Archive) Mode</a> | <a href="https://ag-grid.com/forum/misc.php?action=syndication">RSS Syndication</a></span>
				</div>
			</div>
			</div>
		<hr class="hidden" />
			<div id="copyright">
				<div id="debug"></div>
				<!-- MyBB is free software developed and maintained by a volunteer community.
					 It would be much appreciated by the MyBB Group if you left the full copyright and "powered by" notice intact,
					 to show your support for MyBB.  If you choose to remove or modify the copyright below,
					 you may be refused support on the MyBB Community Forums.

					 This is free software, support us and we'll support you. -->
Powered By <a href="http://mybb.com/" target="_blank">MyBB</a>, &copy; 2002-2016 <a href="http://mybb.com/" target="_blank">MyBB Group</a>.<br />
				<!-- End powered by -->
				<br />
<br class="clear" />
<!-- The following piece of code allows MyBB to run scheduled tasks. DO NOT REMOVE --><!-- End task image code -->

		</div>
		</div>
<!-- end: footer -->
</body>

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=4&page=55 by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:51:00 GMT -->
</html>
<!-- end: forumdisplay -->