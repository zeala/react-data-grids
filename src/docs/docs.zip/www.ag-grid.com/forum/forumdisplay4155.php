<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><!-- start: forumdisplay -->
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=4&page=23 by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:51:20 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<title> - ag-Grid Free Forum (not actively monitored by ag-Grid dev) </title>
<!-- start: headerinclude -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/prototype7321.js?ver=1603"></script>
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/general7321.js?ver=1603"></script>
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/popup_menu0414.js?ver=1600"></script>
<link type="text/css" rel="stylesheet" href="../../ag-grid.com/forum/cache/themes/theme1/global.css" />
<link type="text/css" rel="stylesheet" href="../../ag-grid.com/forum/cache/themes/theme1/star_ratings.css" />

<script type="text/javascript">
<!--
	var cookieDomain = ".ag-grid.com";
	var cookiePath = "index.html";
	var cookiePrefix = "";
	var deleteevent_confirm = "Are you sure you want to delete this event?";
	var removeattach_confirm = "Are you sure you want to remove the selected attachment from this post?";
	var loading_text = 'Loading. <br />Please Wait..';
	var saving_changes = 'Saving changes..';
	var use_xmlhttprequest = "1";
	var my_post_key = "9d9f8e6842db6d8c8a75a10edcf17276";
	var imagepath = "images";
// -->
</script>

<!-- end: headerinclude -->
<!-- start: forumdisplay_rssdiscovery -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads in ag-Grid Free Forum (not actively monitored by ag-Grid dev) (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php?fid=4" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads in ag-Grid Free Forum (not actively monitored by ag-Grid dev) (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0&amp;fid=4" />
<!-- end: forumdisplay_rssdiscovery -->
<script type="text/javascript">
<!--
	lang.no_new_posts = "Forum Contains No New Posts";
	lang.click_mark_read = "Click to mark this forum as read";
// -->
</script>
</head>
<body>
<!-- start: header -->
	<div id="container">
		<a name="top" id="top"></a>
		<div id="header">
			<div class="logo"><a href="index-2.html"><img src="../../ag-grid.com/forum/images/logo.gif" alt="" title="" /></a></div>
			<div class="menu">
				<ul>
					<li><a href="search.php"><img src="images/toplinks/search.gif" alt="" title="" />Search</a></li>
					<li><a href="https://ag-grid.com/forum/memberlist.php"><img src="images/toplinks/memberlist.gif" alt="" title="" />Member List</a></li>
					<li><a href="https://ag-grid.com/forum/calendar.php"><img src="images/toplinks/calendar.gif" alt="" title="" />Calendar</a></li>
					<li><a href="https://ag-grid.com/forum/misc.php?action=help"><img src="images/toplinks/help.gif" alt="" title="" />Help</a></li>
				</ul>
			</div>
			<hr class="hidden" />
			<div id="panel">
				<!-- start: header_welcomeblock_guest -->
<script type="text/javascript">
<!--
	lang.username = "Username";
	lang.password = "Password";
	lang.login = "Login";
	lang.lost_password = " &mdash; <a href=\"member9a16.html?action=lostpw\">Lost Password?<\/a>";
	lang.register_url = " &mdash; <a href=\"member0ddc.php?action=register\">Register<\/a>";
	lang.remember_me = "Remember me";
// -->
</script>
<span style="float: right;"><strong>Current time:</strong> 03-17-2016, 07:50 AM</span>
		<span id="quick_login">Hello There, Guest! (<a href="https://ag-grid.com/forum/member.php?action=login" onclick="MyBB.quickLogin(); return false;">Login</a> &mdash; <a href="member0ddc.php?action=register">Register</a>)</span>
<!-- end: header_welcomeblock_guest -->
			</div>
		</div>
		<hr class="hidden" />
		<br class="clear" />
		<div id="content">
			
			
			
			
			
			<!-- start: nav -->

<div class="navigation">
<!-- start: nav_bit -->
<a href="index-2.html"></a><!-- start: nav_sep -->
 / 
<!-- end: nav_sep -->
<!-- end: nav_bit --><!-- start: nav_bit -->
<a href="forumdisplaye15e.html?fid=3">ag-Grid</a>
<!-- end: nav_bit --><!-- start: nav_sep_active -->
 / 
<!-- end: nav_sep_active --><!-- start: nav_bit_active -->
<span class="active">ag-Grid Free Forum (not actively monitored by ag-Grid dev)</span>
<!-- end: nav_bit_active -->
</div>
<!-- end: nav -->
			<br />

<!-- end: header -->

<!-- start: forumdisplay_usersbrowsing -->
<span class="smalltext">User(s) browsing this forum: 1 Guest(s)</span><br />
<!-- end: forumdisplay_usersbrowsing -->


<!-- start: forumdisplay_threadlist -->
<div class="float_left">
	<!-- start: multipage -->
<div class="pagination">
<span class="pages">Pages (66):</span>
<!-- start: multipage_prevpage -->
<a href="forumdisplaybbb7.php?fid=4&amp;page=22" class="pagination_previous">&laquo; Previous</a>
<!-- end: multipage_prevpage --><!-- start: multipage_start -->
<a href="forumdisplay6925.html?fid=4" class="pagination_first">1</a>  ...
<!-- end: multipage_start --><!-- start: multipage_page -->
<a href="forumdisplay9090.php?fid=4&amp;page=21" class="pagination_page">21</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=22" class="pagination_page">22</a>
<!-- end: multipage_page --><!-- start: multipage_page_current -->
 <span class="pagination_current">23</span>
<!-- end: multipage_page_current --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=24" class="pagination_page">24</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=25" class="pagination_page">25</a>
<!-- end: multipage_page --><!-- start: multipage_end -->
...  <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=66" class="pagination_last">66</a>
<!-- end: multipage_end --><!-- start: multipage_nextpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=24" class="pagination_next">Next &raquo;</a>
<!-- end: multipage_nextpage -->
</div>
<!-- end: multipage -->
</div>
<div class="float_right">
	<!-- start: forumdisplay_newthread -->
<a href="https://www.ag-grid.com/forum/newthread.php?fid=4"><img src="https://www.ag-grid.com/forum/images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<table border="0" cellspacing="1" cellpadding="4" class="tborder" style="clear: both;">
	<tr>
		<td class="thead" colspan="7">
			<div style="float: right;">
				<span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/misc.php?action=markread&amp;fid=4">Mark this forum read</a> | <a href="https://www.ag-grid.com/forum/usercp2.php?action=addsubscription&amp;type=forum&amp;fid=4&amp;my_post_key=9d9f8e6842db6d8c8a75a10edcf17276">Subscribe to this forum</a></strong></span>
			</div>
			<div>
				<strong>ag-Grid Free Forum (not actively monitored by ag-Grid dev)</strong>
			</div>
		</td>
	</tr>
	<tr>
		<td class="tcat" colspan="3" width="66%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=23&amp;datecut=0&amp;sortby=subject&amp;order=asc">Thread</a>  / <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=23&amp;datecut=0&amp;sortby=starter&amp;order=asc">Author</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=23&amp;datecut=0&amp;sortby=replies&amp;order=desc">Replies</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=23&amp;datecut=0&amp;sortby=views&amp;order=desc">Views</a> </strong></span></td>
		<!-- start: forumdisplay_threadlist_rating -->
	<td class="tcat" align="center" width="80">
		<span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=23&amp;datecut=0&amp;sortby=rating&amp;order=desc">Rating</a> </strong></span>
		<script type="text/javascript" src="https://www.ag-grid.com/forum/jscripts/rating.js?ver=1400"></script>
		<script type="text/javascript">
		<!--
			lang.stars = new Array();
			lang.stars[1] = "1 star out of 5";
			lang.stars[2] = "2 stars out of 5";
			lang.stars[3] = "3 stars out of 5";
			lang.stars[4] = "4 stars out of 5";
			lang.stars[5] = "5 stars out of 5";
		// -->
		</script>
	</td>

<!-- end: forumdisplay_threadlist_rating -->
		<td class="tcat" align="right" width="20%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=23&amp;datecut=0&amp;sortby=lastpost&amp;order=desc">Last Post</a> <!-- start: forumdisplay_orderarrow -->
<span class="smalltext">[<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=23&amp;datecut=0&amp;sortby=lastpost&amp;order=asc">asc</a>]</span>
<!-- end: forumdisplay_orderarrow --></strong></span></td>
		
	</tr>
	
	
	<!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3032" class=" subject_old" id="tid_3032">Uh-Oh</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=499">xeon48</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3032);">7</a></td>
	<td align="center" class="trow1 forumdisplay_regular">139</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3032">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3032">
			<li style="width: 0%" class="current_rating" id="current_rating_3032">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3032, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 04:42 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3032&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=647">jandrews</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3061" class=" subject_old" id="tid_3061">Displaying A Filter Based on Parameters</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=845">andycheng</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3061);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">50</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3061">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3061">
			<li style="width: 0%" class="current_rating" id="current_rating_3061">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3061, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:58 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3061&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3058" class=" subject_old" id="tid_3058">headerGroup value getter?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=499">xeon48</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3058);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">40</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3058">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3058">
			<li style="width: 0%" class="current_rating" id="current_rating_3058">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3058, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:48 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3058&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3055" class=" subject_old" id="tid_3055">Edit and delete a row</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=881">rebecca</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3055);">2</a></td>
	<td align="center" class="trow2 forumdisplay_regular">164</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3055">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3055">
			<li style="width: 60%" class="current_rating" id="current_rating_3055">1 Vote(s) - 3 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3055, { width: '60', extra_class: ' star_rating_notrated', current_average: '1 Vote(s) - 3 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:41 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3055&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3051" class=" subject_old" id="tid_3051">Trouble with Value / Aggregate Columns</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=647">jandrews</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3051);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">46</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3051">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3051">
			<li style="width: 0%" class="current_rating" id="current_rating_3051">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3051, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:32 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3051&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3050" class=" subject_old" id="tid_3050">Multiple grid with same grid options</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=742">navijayvargiya</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3050);">4</a></td>
	<td align="center" class="trow2 forumdisplay_regular">102</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3050">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3050">
			<li style="width: 0%" class="current_rating" id="current_rating_3050">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3050, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:31 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3050&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		<!-- start: forumdisplay_thread_attachment_count -->
<div style="float: right;"><img src="https://www.ag-grid.com/forum/images/paperclip.gif" alt="" title="This thread contains 1 attachment." /></div>
<!-- end: forumdisplay_thread_attachment_count -->
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3042" class=" subject_old" id="tid_3042">Ag-Grid Implementation - Loading Issues taking long time</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=851">breddy</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3042);">7</a></td>
	<td align="center" class="trow1 forumdisplay_regular">215</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3042">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3042">
			<li style="width: 0%" class="current_rating" id="current_rating_3042">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3042, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:30 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3042&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3046" class=" subject_old" id="tid_3046">showLoading text is not working</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=873">amirreza</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3046);">3</a></td>
	<td align="center" class="trow2 forumdisplay_regular">115</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3046">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3046">
			<li style="width: 0%" class="current_rating" id="current_rating_3046">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3046, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:24 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3046&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3043" class=" subject_old" id="tid_3043">Take header name based on object value's name</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=499">xeon48</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3043);">5</a></td>
	<td align="center" class="trow1 forumdisplay_regular">87</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3043">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3043">
			<li style="width: 0%" class="current_rating" id="current_rating_3043">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3043, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:20 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3043&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3047" class=" subject_old" id="tid_3047">Perma-sort column</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=857">siegdubhy</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3047);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">51</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3047">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3047">
			<li style="width: 0%" class="current_rating" id="current_rating_3047">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3047, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:10 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3047&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3044" class=" subject_old" id="tid_3044">Auto size column widths to header name</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=282">king612</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3044);">4</a></td>
	<td align="center" class="trow1 forumdisplay_regular">135</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3044">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3044">
			<li style="width: 0%" class="current_rating" id="current_rating_3044">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3044, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:08 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3044&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3041" class=" subject_old" id="tid_3041">GroupKey display name</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=647">jandrews</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3041);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">46</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3041">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3041">
			<li style="width: 0%" class="current_rating" id="current_rating_3041">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3041, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:07 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3041&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3040" class=" subject_old" id="tid_3040">Column groups collapse when the columns change</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=759">DougGrimwade</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3040);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">46</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3040">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3040">
			<li style="width: 0%" class="current_rating" id="current_rating_3040">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3040, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-05-2015 03:05 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3040&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3052" class=" subject_old" id="tid_3052">Unable to Export (cannot read property 'api' of undefined error.)</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=846">ayesha</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3052);">3</a></td>
	<td align="center" class="trow2 forumdisplay_regular">92</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3052">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3052">
			<li style="width: 0%" class="current_rating" id="current_rating_3052">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3052, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-04-2015 08:45 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3052&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=499">xeon48</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3053" class=" subject_old" id="tid_3053">Group Column Definition</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=647">jandrews</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3053);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">100</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3053">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3053">
			<li style="width: 0%" class="current_rating" id="current_rating_3053">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3053, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-04-2015 11:47 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3053&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=882">jrynlds</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3049" class=" subject_old" id="tid_3049">Row as link?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=878">fr0z3n</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3049);">2</a></td>
	<td align="center" class="trow2 forumdisplay_regular">92</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3049">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3049">
			<li style="width: 100%" class="current_rating" id="current_rating_3049">2 Vote(s) - 5 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3049, { width: '100', extra_class: ' star_rating_notrated', current_average: '2 Vote(s) - 5 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-03-2015 10:46 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3049&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=878">fr0z3n</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3039" class=" subject_old" id="tid_3039">AG-Grid Javascript Grid Loaded Event</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=851">breddy</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3039);">2</a></td>
	<td align="center" class="trow1 forumdisplay_regular">73</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3039">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3039">
			<li style="width: 0%" class="current_rating" id="current_rating_3039">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3039, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-03-2015 05:51 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3039&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=875">ajay11</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/icons/exclamation.gif" alt="Exclamation" /></td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3031" class=" subject_old" id="tid_3031">select rows by pressing ShiftKey</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=591">Joe</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3031);">2</a></td>
	<td align="center" class="trow2 forumdisplay_regular">87</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3031">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3031">
			<li style="width: 0%" class="current_rating" id="current_rating_3031">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3031, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-02-2015 10:48 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3031&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=299">arnoldmq</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3028" class=" subject_old" id="tid_3028">2 new options</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=850">reno_tidus</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3028);">4</a></td>
	<td align="center" class="trow1 forumdisplay_regular">170</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3028">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3028">
			<li style="width: 100%" class="current_rating" id="current_rating_3028">1 Vote(s) - 5 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3028, { width: '100', extra_class: ' star_rating_notrated', current_average: '1 Vote(s) - 5 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-02-2015 09:08 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3028&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=850">reno_tidus</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2356" class=" subject_old" id="tid_2356">Checkbox select all in header column using angular</a><!-- start: forumdisplay_thread_multipage -->
 <span class="smalltext">(Pages: <!-- start: forumdisplay_thread_multipage_page -->
<a href="https://www.ag-grid.com/forum/showthread.php?tid=2356">1</a> 
<!-- end: forumdisplay_thread_multipage_page --><!-- start: forumdisplay_thread_multipage_page -->
<a href="https://www.ag-grid.com/forum/showthread.php?tid=2356&amp;page=2">2</a> 
<!-- end: forumdisplay_thread_multipage_page -->)</span>
<!-- end: forumdisplay_thread_multipage --></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=303">@ron</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2356);">11</a></td>
	<td align="center" class="trow2 forumdisplay_regular">1,692</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2356">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2356">
			<li style="width: 0%" class="current_rating" id="current_rating_2356">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2356, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-02-2015 06:30 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2356&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=870">project-net</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread -->
	<tr>
		<td class="tfoot" align="right" colspan="7">
			<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
				<input type="hidden" name="selectall" value="" />
				<input type="hidden" name="fid" value="4" />
				<select name="sortby">
					<option value="subject" >Sort by: Subject</option>
					<option value="lastpost" selected="selected">Sort by: Last Post</option>
					<option value="starter" >Sort by: Author</option>
					<option value="started" >Sort by: Creation Time</option>
					<!-- start: forumdisplay_threadlist_sortrating -->
<option value="rating" >Sort by: Rating</option>
<!-- end: forumdisplay_threadlist_sortrating -->
					<option value="replies" >Sort by: Replies</option>
					<option value="views" >Sort by: Views</option>
				</select>
				<select name="order">
					<option value="asc" >Order: Ascending</option>
					<option value="desc" selected="selected">Order: Descending</option>
				</select>
				<select name="datecut">
					<option value="1" >From: Today</option>
					<option value="5" >From: 5 Days Ago</option>
					<option value="10" >From: 10 Days Ago</option>
					<option value="20" >From: 20 Days Ago</option>
					<option value="50" >From: 50 Days Ago</option>
					<option value="75" >From: 75 Days Ago</option>
					<option value="100" >From: 100 Days Ago</option>
					<option value="365" >From: The Last Year</option>
					<option value="9999" >From: The Beginning</option>
				</select>
				<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
			</form>
		</td>
	</tr>
</table>
<div class="float_left">
	<!-- start: multipage -->
<div class="pagination">
<span class="pages">Pages (66):</span>
<!-- start: multipage_prevpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=22" class="pagination_previous">&laquo; Previous</a>
<!-- end: multipage_prevpage --><!-- start: multipage_start -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4" class="pagination_first">1</a>  ...
<!-- end: multipage_start --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=21" class="pagination_page">21</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=22" class="pagination_page">22</a>
<!-- end: multipage_page --><!-- start: multipage_page_current -->
 <span class="pagination_current">23</span>
<!-- end: multipage_page_current --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=24" class="pagination_page">24</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=25" class="pagination_page">25</a>
<!-- end: multipage_page --><!-- start: multipage_end -->
...  <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=66" class="pagination_last">66</a>
<!-- end: multipage_end --><!-- start: multipage_nextpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=24" class="pagination_next">Next &raquo;</a>
<!-- end: multipage_nextpage -->
</div>
<!-- end: multipage -->
</div>
<div class="float_right" style="margin-top: 4px;">
	<!-- start: forumdisplay_newthread -->
<a href="https://www.ag-grid.com/forum/newthread.php?fid=4"><img src="https://www.ag-grid.com/forum/images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<br style="clear: both;" />
<br />
<div class="float_left">
	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="https://www.ag-grid.com/forum/images/newfolder.gif" alt="New Posts" title="New Posts" /> New Posts</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/newhotfolder.gif" alt="Hot Thread (New)" title="Hot Thread (New)" /> Hot Thread (New)</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="Hot Thread (No New)" title="Hot Thread (No New)" /> Hot Thread (No New)</dd>
		</dl>
	</div>

	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No New Posts" title="No New Posts" /> No New Posts</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/dot_folder.gif" alt="Contains Posts by You" title="Contains Posts by You" /> Contains Posts by You</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/lockfolder.gif" alt="Locked Thread" title="Locked Thread" /> Locked Thread</dd>
		</dl>
	</div>
	<br style="clear: both" />
</div>

<div class="float_right" style="text-align: right;">
	
	<!-- start: forumdisplay_searchforum -->
<form action="https://www.ag-grid.com/forum/search.php" method="post">
	<span class="smalltext"><strong>Search this Forum:</strong></span>
	<input type="text" class="textbox" name="keywords" /> <!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	<input type="hidden" name="action" value="do_search" />
	<input type="hidden" name="forums" value="4" />
	<input type="hidden" name="postthread" value="1" />
	</form><br />
<!-- end: forumdisplay_searchforum -->
	<!-- start: forumjump_advanced -->
<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
<span class="smalltext"><strong>Forum Jump:</strong></span>
<select name="fid" class="forumjump">
<option value="-1" >Please select one:</option>
<option value="-1">--------------------</option>
<option value="-4">Private Messages</option>
<option value="-3">User Control Panel</option>
<option value="-5">Who's Online</option>
<option value="-2">Search</option>
<option value="-1">Forum Home</option>
<!-- start: forumjump_bit -->
<option value="3" > ag-Grid</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="4" selected="selected">-- ag-Grid Free Forum (not actively monitored by ag-Grid dev)</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="5" >-- ag-Grid Members Forum (only members can post, monitored daily by ag-Grid dev)</option>
<!-- end: forumjump_bit -->
</select>
<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
</form>
<script type="text/javascript">
<!--
	$$('.forumjump').invoke('observe', 'change', function(e)
	{
		var option = this.options[this.selectedIndex].value

		if(option < 0)
		{
			window.location=('https://www.ag-grid.com/forum/forumdisplay.php?fid='+option)
			return
		}

		window.location=('https://www.ag-grid.com/forum/forumdisplay.php?fid='+this.options[this.selectedIndex].value)
	})
//-->
</script>
<!-- end: forumjump_advanced -->
</div>
<br style="clear: both" />
<!-- start: forumdisplay_threadlist_inlineedit_js -->
<script type="text/javascript" src="https://www.ag-grid.com/forum/jscripts/inline_edit.js?ver=1400"></script>
<script type="text/javascript">
<!--
	if(use_xmlhttprequest == "1")
	{
		new inlineEditor("https://www.ag-grid.com/forum/xmlhttp.php?action=edit_subject&amp;my_post_key="+my_post_key, {className: "subject_editable", spinnerImage: "images/spinner.gif", lang_click_edit: "(Click and hold to edit)"});
	}
// -->
</script>
<!-- end: forumdisplay_threadlist_inlineedit_js -->
<!-- end: forumdisplay_threadlist -->
<!-- start: footer -->
			<br />
			<div class="bottommenu">
				<div class="float_right"><!-- start: footer_languageselect -->
<form method="get" action="https://www.ag-grid.com/forum/forumdisplay.php" id="lang_select">
		<input type="hidden" name="fid" value="4" />
<input type="hidden" name="page" value="23" />

		<input type="hidden" name="my_post_key" value="9d9f8e6842db6d8c8a75a10edcf17276" />
		<select name="language" onchange="MyBB.changeLanguage();">
			<optgroup label="Quick Language Select">
				<option value="english" selected="selected">&nbsp;&nbsp;&nbsp;English (American)</option>

			</optgroup>
		</select>
		<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	</form>
<!-- end: footer_languageselect --></div>
				<div>
					<span class="smalltext"><a href="mailto:webmaster@angulargrid.com">Contact Us</a> | <a href="https://www.ag-grid.com/">ag-Grid Forum</a> | <a href="#top">Return to Top</a> | <a href="#content">Return to Content</a> | <a href="https://ag-grid.com/forum/archive/index.php?forum-4.html">Lite (Archive) Mode</a> | <a href="https://ag-grid.com/forum/misc.php?action=syndication">RSS Syndication</a></span>
				</div>
			</div>
			</div>
		<hr class="hidden" />
			<div id="copyright">
				<div id="debug"></div>
				<!-- MyBB is free software developed and maintained by a volunteer community.
					 It would be much appreciated by the MyBB Group if you left the full copyright and "powered by" notice intact,
					 to show your support for MyBB.  If you choose to remove or modify the copyright below,
					 you may be refused support on the MyBB Community Forums.

					 This is free software, support us and we'll support you. -->
Powered By <a href="http://mybb.com/" target="_blank">MyBB</a>, &copy; 2002-2016 <a href="http://mybb.com/" target="_blank">MyBB Group</a>.<br />
				<!-- End powered by -->
				<br />
<br class="clear" />
<!-- The following piece of code allows MyBB to run scheduled tasks. DO NOT REMOVE --><!-- End task image code -->

		</div>
		</div>
<!-- end: footer -->
</body>

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=4&page=23 by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:51:20 GMT -->
</html>
<!-- end: forumdisplay -->