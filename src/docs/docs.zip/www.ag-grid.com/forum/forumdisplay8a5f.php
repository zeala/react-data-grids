<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><!-- start: forumdisplay -->
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=4&page=13&datecut=0&sortby=subject&order=asc by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:51:43 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<title> - ag-Grid Free Forum (not actively monitored by ag-Grid dev) </title>
<!-- start: headerinclude -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/prototype7321.js?ver=1603"></script>
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/general7321.js?ver=1603"></script>
<script type="text/javascript" src="../../ag-grid.com/forum/jscripts/popup_menu0414.js?ver=1600"></script>
<link type="text/css" rel="stylesheet" href="../../ag-grid.com/forum/cache/themes/theme1/global.css" />
<link type="text/css" rel="stylesheet" href="../../ag-grid.com/forum/cache/themes/theme1/star_ratings.css" />

<script type="text/javascript">
<!--
	var cookieDomain = ".ag-grid.com";
	var cookiePath = "index.html";
	var cookiePrefix = "";
	var deleteevent_confirm = "Are you sure you want to delete this event?";
	var removeattach_confirm = "Are you sure you want to remove the selected attachment from this post?";
	var loading_text = 'Loading. <br />Please Wait..';
	var saving_changes = 'Saving changes..';
	var use_xmlhttprequest = "1";
	var my_post_key = "9d9f8e6842db6d8c8a75a10edcf17276";
	var imagepath = "images";
// -->
</script>

<!-- end: headerinclude -->
<!-- start: forumdisplay_rssdiscovery -->
<link rel="alternate" type="application/rss+xml" title="Latest Threads in ag-Grid Free Forum (not actively monitored by ag-Grid dev) (RSS 2.0)" href="https://ag-grid.com/forum/syndication.php?fid=4" />
<link rel="alternate" type="application/atom+xml" title="Latest Threads in ag-Grid Free Forum (not actively monitored by ag-Grid dev) (Atom 1.0)" href="https://ag-grid.com/forum/syndication.php?type=atom1.0&amp;fid=4" />
<!-- end: forumdisplay_rssdiscovery -->
<script type="text/javascript">
<!--
	lang.no_new_posts = "Forum Contains No New Posts";
	lang.click_mark_read = "Click to mark this forum as read";
// -->
</script>
</head>
<body>
<!-- start: header -->
	<div id="container">
		<a name="top" id="top"></a>
		<div id="header">
			<div class="logo"><a href="index-2.html"><img src="../../ag-grid.com/forum/images/logo.gif" alt="" title="" /></a></div>
			<div class="menu">
				<ul>
					<li><a href="search.php"><img src="images/toplinks/search.gif" alt="" title="" />Search</a></li>
					<li><a href="https://ag-grid.com/forum/memberlist.php"><img src="images/toplinks/memberlist.gif" alt="" title="" />Member List</a></li>
					<li><a href="https://ag-grid.com/forum/calendar.php"><img src="images/toplinks/calendar.gif" alt="" title="" />Calendar</a></li>
					<li><a href="https://ag-grid.com/forum/misc.php?action=help"><img src="images/toplinks/help.gif" alt="" title="" />Help</a></li>
				</ul>
			</div>
			<hr class="hidden" />
			<div id="panel">
				<!-- start: header_welcomeblock_guest -->
<script type="text/javascript">
<!--
	lang.username = "Username";
	lang.password = "Password";
	lang.login = "Login";
	lang.lost_password = " &mdash; <a href=\"member9a16.html?action=lostpw\">Lost Password?<\/a>";
	lang.register_url = " &mdash; <a href=\"member0ddc.php?action=register\">Register<\/a>";
	lang.remember_me = "Remember me";
// -->
</script>
<span style="float: right;"><strong>Current time:</strong> 03-17-2016, 07:51 AM</span>
		<span id="quick_login">Hello There, Guest! (<a href="https://ag-grid.com/forum/member.php?action=login" onclick="MyBB.quickLogin(); return false;">Login</a> &mdash; <a href="member0ddc.php?action=register">Register</a>)</span>
<!-- end: header_welcomeblock_guest -->
			</div>
		</div>
		<hr class="hidden" />
		<br class="clear" />
		<div id="content">
			
			
			
			
			
			<!-- start: nav -->

<div class="navigation">
<!-- start: nav_bit -->
<a href="index-2.html"></a><!-- start: nav_sep -->
 / 
<!-- end: nav_sep -->
<!-- end: nav_bit --><!-- start: nav_bit -->
<a href="forumdisplaye15e.html?fid=3">ag-Grid</a>
<!-- end: nav_bit --><!-- start: nav_sep_active -->
 / 
<!-- end: nav_sep_active --><!-- start: nav_bit_active -->
<span class="active">ag-Grid Free Forum (not actively monitored by ag-Grid dev)</span>
<!-- end: nav_bit_active -->
</div>
<!-- end: nav -->
			<br />

<!-- end: header -->

<!-- start: forumdisplay_usersbrowsing -->
<span class="smalltext">User(s) browsing this forum: 1 Guest(s)</span><br />
<!-- end: forumdisplay_usersbrowsing -->


<!-- start: forumdisplay_threadlist -->
<div class="float_left">
	<!-- start: multipage -->
<div class="pagination">
<span class="pages">Pages (66):</span>
<!-- start: multipage_prevpage -->
<a href="forumdisplayfef1.php?fid=4&amp;page=12&amp;sortby=subject&amp;order=asc" class="pagination_previous">&laquo; Previous</a>
<!-- end: multipage_prevpage --><!-- start: multipage_start -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;sortby=subject&amp;order=asc" class="pagination_first">1</a>  ...
<!-- end: multipage_start --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=11&amp;sortby=subject&amp;order=asc" class="pagination_page">11</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=12&amp;sortby=subject&amp;order=asc" class="pagination_page">12</a>
<!-- end: multipage_page --><!-- start: multipage_page_current -->
 <span class="pagination_current">13</span>
<!-- end: multipage_page_current --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=14&amp;sortby=subject&amp;order=asc" class="pagination_page">14</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=15&amp;sortby=subject&amp;order=asc" class="pagination_page">15</a>
<!-- end: multipage_page --><!-- start: multipage_end -->
...  <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=66&amp;sortby=subject&amp;order=asc" class="pagination_last">66</a>
<!-- end: multipage_end --><!-- start: multipage_nextpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=14&amp;sortby=subject&amp;order=asc" class="pagination_next">Next &raquo;</a>
<!-- end: multipage_nextpage -->
</div>
<!-- end: multipage -->
</div>
<div class="float_right">
	<!-- start: forumdisplay_newthread -->
<a href="https://www.ag-grid.com/forum/newthread.php?fid=4"><img src="https://www.ag-grid.com/forum/images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<table border="0" cellspacing="1" cellpadding="4" class="tborder" style="clear: both;">
	<tr>
		<td class="thead" colspan="7">
			<div style="float: right;">
				<span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/misc.php?action=markread&amp;fid=4">Mark this forum read</a> | <a href="https://www.ag-grid.com/forum/usercp2.php?action=addsubscription&amp;type=forum&amp;fid=4&amp;my_post_key=9d9f8e6842db6d8c8a75a10edcf17276">Subscribe to this forum</a></strong></span>
			</div>
			<div>
				<strong>ag-Grid Free Forum (not actively monitored by ag-Grid dev)</strong>
			</div>
		</td>
	</tr>
	<tr>
		<td class="tcat" colspan="3" width="66%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=13&amp;datecut=0&amp;sortby=subject&amp;order=asc">Thread</a> <!-- start: forumdisplay_orderarrow -->
<span class="smalltext">[<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=13&amp;datecut=0&amp;sortby=subject&amp;order=desc">desc</a>]</span>
<!-- end: forumdisplay_orderarrow --> / <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=13&amp;datecut=0&amp;sortby=starter&amp;order=asc">Author</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=13&amp;datecut=0&amp;sortby=replies&amp;order=desc">Replies</a> </strong></span></td>
		<td class="tcat" align="center" width="7%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=13&amp;datecut=0&amp;sortby=views&amp;order=desc">Views</a> </strong></span></td>
		<!-- start: forumdisplay_threadlist_rating -->
	<td class="tcat" align="center" width="80">
		<span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=13&amp;datecut=0&amp;sortby=rating&amp;order=desc">Rating</a> </strong></span>
		<script type="text/javascript" src="https://www.ag-grid.com/forum/jscripts/rating.js?ver=1400"></script>
		<script type="text/javascript">
		<!--
			lang.stars = new Array();
			lang.stars[1] = "1 star out of 5";
			lang.stars[2] = "2 stars out of 5";
			lang.stars[3] = "3 stars out of 5";
			lang.stars[4] = "4 stars out of 5";
			lang.stars[5] = "5 stars out of 5";
		// -->
		</script>
	</td>

<!-- end: forumdisplay_threadlist_rating -->
		<td class="tcat" align="right" width="20%"><span class="smalltext"><strong><a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=13&amp;datecut=0&amp;sortby=lastpost&amp;order=desc">Last Post</a> </strong></span></td>
		
	</tr>
	
	
	<!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3074" class=" subject_old" id="tid_3074">change column styling</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=825">rlamba89</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3074);">2</a></td>
	<td align="center" class="trow1 forumdisplay_regular">100</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3074">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3074">
			<li style="width: 0%" class="current_rating" id="current_rating_3074">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3074, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-10-2015 07:51 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3074&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3198" class=" subject_old" id="tid_3198">Change grouped row name</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=825">rlamba89</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3198);">6</a></td>
	<td align="center" class="trow2 forumdisplay_regular">82</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3198">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3198">
			<li style="width: 0%" class="current_rating" id="current_rating_3198">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3198, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">12-18-2015 11:08 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3198&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		<!-- start: forumdisplay_thread_attachment_count -->
<div style="float: right;"><img src="https://www.ag-grid.com/forum/images/paperclip.gif" alt="" title="This thread contains 3 attachments." /></div>
<!-- end: forumdisplay_thread_attachment_count -->
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2744" class=" subject_old" id="tid_2744">change headerGroup not working</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=580">svimma23</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2744);">4</a></td>
	<td align="center" class="trow1 forumdisplay_regular">276</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2744">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2744">
			<li style="width: 0%" class="current_rating" id="current_rating_2744">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2744, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">09-07-2015 12:12 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2744&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=580">svimma23</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3013" class=" subject_old" id="tid_3013">Change headerTitle after collapse/expand</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=503">amirox</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3013);">3</a></td>
	<td align="center" class="trow2 forumdisplay_regular">92</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3013">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3013">
			<li style="width: 100%" class="current_rating" id="current_rating_3013">1 Vote(s) - 5 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3013, { width: '100', extra_class: ' star_rating_notrated', current_average: '1 Vote(s) - 5 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-11-2015 12:46 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3013&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2752" class=" subject_old" id="tid_2752">Change language of pagination</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=605">kappa</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2752);">4</a></td>
	<td align="center" class="trow1 forumdisplay_regular">297</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2752">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2752">
			<li style="width: 0%" class="current_rating" id="current_rating_2752">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2752, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">09-17-2015 09:52 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2752&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=642">bernfarr</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/icons/question.gif" alt="Question" /></td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=10" class=" subject_old" id="tid_10">Change order of columns by dragging?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=19">beernutz</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(10);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">498</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_10">
		<ul class="star_rating star_rating_notrated" id="rating_thread_10">
			<li style="width: 0%" class="current_rating" id="current_rating_10">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(10, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">04-02-2015 05:22 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=10&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3006" class=" subject_old" id="tid_3006">Change page size</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=843">Klip</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3006);">3</a></td>
	<td align="center" class="trow1 forumdisplay_regular">82</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3006">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3006">
			<li style="width: 0%" class="current_rating" id="current_rating_3006">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3006, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">10-30-2015 03:01 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3006&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3161" class=" subject_old" id="tid_3161">Change Row Height When Grouping</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=845">andycheng</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3161);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">48</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3161">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3161">
			<li style="width: 0%" class="current_rating" id="current_rating_3161">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3161, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">12-03-2015 10:56 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3161&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2781" class=" subject_old" id="tid_2781">Change State</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=443">zsivo</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2781);">2</a></td>
	<td align="center" class="trow1 forumdisplay_regular">146</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2781">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2781">
			<li style="width: 0%" class="current_rating" id="current_rating_2781">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2781, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">09-15-2015 01:59 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2781&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=443">zsivo</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3190" class=" subject_old" id="tid_3190">Change style of grid on page (by user)</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=881">rebecca</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3190);">1</a></td>
	<td align="center" class="trow2 forumdisplay_regular">43</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3190">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3190">
			<li style="width: 0%" class="current_rating" id="current_rating_3190">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3190, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">12-15-2015 06:06 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3190&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=711">walfrat</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=111" class=" subject_old" id="tid_111">change to grouping cell rendering?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=110">chrisperfer</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(111);">2</a></td>
	<td align="center" class="trow1 forumdisplay_regular">546</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_111">
		<ul class="star_rating star_rating_notrated" id="rating_thread_111">
			<li style="width: 0%" class="current_rating" id="current_rating_111">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(111, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-19-2015 09:18 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=111&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=110">chrisperfer</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2325" class=" subject_old" id="tid_2325">Change visibility of columns</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=275">asqan</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2325);">2</a></td>
	<td align="center" class="trow2 forumdisplay_regular">273</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2325">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2325">
			<li style="width: 0%" class="current_rating" id="current_rating_2325">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2325, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">06-16-2015 09:35 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2325&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=275">asqan</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3325" class=" subject_old" id="tid_3325">Changes from 3.0 to 3.1.2: Column Spill</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1295">Bart</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3325);">6</a></td>
	<td align="center" class="trow1 forumdisplay_regular">100</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3325">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3325">
			<li style="width: 0%" class="current_rating" id="current_rating_3325">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3325, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">01-29-2016 04:46 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3325&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1295">Bart</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3122" class=" subject_old" id="tid_3122">Changing default filter type for Text and Number filters</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=962">killyosaur</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3122);">3</a></td>
	<td align="center" class="trow2 forumdisplay_regular">51</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3122">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3122">
			<li style="width: 0%" class="current_rating" id="current_rating_3122">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3122, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-24-2015 06:02 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3122&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=711">walfrat</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3413" class=" subject_old" id="tid_3413">Changing enableFilter after the grid is initialized in Angular 1</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1255">bu7emba</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3413);">2</a></td>
	<td align="center" class="trow1 forumdisplay_regular">33</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_3413">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3413">
			<li style="width: 0%" class="current_rating" id="current_rating_3413">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3413, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">02-12-2016 07:59 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3413&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1255">bu7emba</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3037" class=" subject_old" id="tid_3037">changing paddingFactor for groups?</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=632">rufio</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3037);">0</a></td>
	<td align="center" class="trow2 forumdisplay_regular">41</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3037">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3037">
			<li style="width: 0%" class="current_rating" id="current_rating_3037">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3037, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">11-01-2015 07:42 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3037&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=632">rufio</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2422" class=" subject_old" id="tid_2422">changing pinnedColumnCount</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=301">petrovitch</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2422);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">232</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2422">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2422">
			<li style="width: 0%" class="current_rating" id="current_rating_2422">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2422, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">07-04-2015 06:14 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2422&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No new posts." title="No new posts." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=3420" class=" subject_old" id="tid_3420">Changing the pagination look &amp; feel like Kenod</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1403">Ravi</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(3420);">0</a></td>
	<td align="center" class="trow2 forumdisplay_regular">28</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_3420">
		<ul class="star_rating star_rating_notrated" id="rating_thread_3420">
			<li style="width: 0%" class="current_rating" id="current_rating_3420">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(3420, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">02-13-2016 12:14 AM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=3420&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1403">Ravi</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow1 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow1 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow1 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2214" class=" subject_old" id="tid_2214">Check current width of the all column in grid before using sizeColumnsToFit</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=72">ruwantha.ratnayake</a></div>
		</div>
	</td>
	<td align="center" class="trow1 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2214);">1</a></td>
	<td align="center" class="trow1 forumdisplay_regular">288</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow1 forumdisplay_regular" id="rating_table_2214">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2214">
			<li style="width: 0%" class="current_rating" id="current_rating_2214">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2214, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow1 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">05-27-2015 09:14 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2214&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=1">ceolter</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread --><!-- start: forumdisplay_thread -->
<tr>
	<td align="center" class="trow2 forumdisplay_regular" width="2%"><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="No new posts. Hot thread." title="No new posts. Hot thread." /></td>
	<td align="center" class="trow2 forumdisplay_regular" width="2%">&nbsp;</td>
	<td class="trow2 forumdisplay_regular">
		
		<div>
			<span> <a href="https://www.ag-grid.com/forum/showthread.php?tid=2655" class=" subject_old" id="tid_2655">Checkbox on group heading</a></span>
			<div class="author smalltext"><a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=27">puruzio</a></div>
		</div>
	</td>
	<td align="center" class="trow2 forumdisplay_regular"><a href="javascript:MyBB.whoPosted(2655);">2</a></td>
	<td align="center" class="trow2 forumdisplay_regular">406</td>
	<!-- start: forumdisplay_thread_rating -->
<td align="center" class="trow2 forumdisplay_regular" id="rating_table_2655">
		<ul class="star_rating star_rating_notrated" id="rating_thread_2655">
			<li style="width: 0%" class="current_rating" id="current_rating_2655">0 Vote(s) - 0 out of 5 in Average</li>
		</ul>
		<script type="text/javascript">
		<!--
			Rating.build_forumdisplay(2655, { width: '0', extra_class: ' star_rating_notrated', current_average: '0 Vote(s) - 0 out of 5 in Average' });
		// -->
		</script>
	</td>

<!-- end: forumdisplay_thread_rating -->
	<td class="trow2 forumdisplay_regular" style="white-space: nowrap; text-align: right;">
		<span class="lastpost smalltext">09-05-2015 05:08 PM<br />
		<a href="https://www.ag-grid.com/forum/showthread.php?tid=2655&amp;action=lastpost">Last Post</a>: <a href="https://ag-grid.com/forum/member.php?action=profile&amp;uid=27">puruzio</a></span>
	</td>

</tr>

<!-- end: forumdisplay_thread -->
	<tr>
		<td class="tfoot" align="right" colspan="7">
			<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
				<input type="hidden" name="selectall" value="" />
				<input type="hidden" name="fid" value="4" />
				<select name="sortby">
					<option value="subject" selected="selected">Sort by: Subject</option>
					<option value="lastpost" >Sort by: Last Post</option>
					<option value="starter" >Sort by: Author</option>
					<option value="started" >Sort by: Creation Time</option>
					<!-- start: forumdisplay_threadlist_sortrating -->
<option value="rating" >Sort by: Rating</option>
<!-- end: forumdisplay_threadlist_sortrating -->
					<option value="replies" >Sort by: Replies</option>
					<option value="views" >Sort by: Views</option>
				</select>
				<select name="order">
					<option value="asc" selected="selected">Order: Ascending</option>
					<option value="desc" >Order: Descending</option>
				</select>
				<select name="datecut">
					<option value="1" >From: Today</option>
					<option value="5" >From: 5 Days Ago</option>
					<option value="10" >From: 10 Days Ago</option>
					<option value="20" >From: 20 Days Ago</option>
					<option value="50" >From: 50 Days Ago</option>
					<option value="75" >From: 75 Days Ago</option>
					<option value="100" >From: 100 Days Ago</option>
					<option value="365" >From: The Last Year</option>
					<option value="9999" >From: The Beginning</option>
				</select>
				<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
			</form>
		</td>
	</tr>
</table>
<div class="float_left">
	<!-- start: multipage -->
<div class="pagination">
<span class="pages">Pages (66):</span>
<!-- start: multipage_prevpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=12&amp;sortby=subject&amp;order=asc" class="pagination_previous">&laquo; Previous</a>
<!-- end: multipage_prevpage --><!-- start: multipage_start -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;sortby=subject&amp;order=asc" class="pagination_first">1</a>  ...
<!-- end: multipage_start --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=11&amp;sortby=subject&amp;order=asc" class="pagination_page">11</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=12&amp;sortby=subject&amp;order=asc" class="pagination_page">12</a>
<!-- end: multipage_page --><!-- start: multipage_page_current -->
 <span class="pagination_current">13</span>
<!-- end: multipage_page_current --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=14&amp;sortby=subject&amp;order=asc" class="pagination_page">14</a>
<!-- end: multipage_page --><!-- start: multipage_page -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=15&amp;sortby=subject&amp;order=asc" class="pagination_page">15</a>
<!-- end: multipage_page --><!-- start: multipage_end -->
...  <a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=66&amp;sortby=subject&amp;order=asc" class="pagination_last">66</a>
<!-- end: multipage_end --><!-- start: multipage_nextpage -->
<a href="https://www.ag-grid.com/forum/forumdisplay.php?fid=4&amp;page=14&amp;sortby=subject&amp;order=asc" class="pagination_next">Next &raquo;</a>
<!-- end: multipage_nextpage -->
</div>
<!-- end: multipage -->
</div>
<div class="float_right" style="margin-top: 4px;">
	<!-- start: forumdisplay_newthread -->
<a href="https://www.ag-grid.com/forum/newthread.php?fid=4"><img src="https://www.ag-grid.com/forum/images/english/newthread.gif" alt="Post Thread" title="Post Thread" /></a>
<!-- end: forumdisplay_newthread -->
</div>
<br style="clear: both;" />
<br />
<div class="float_left">
	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="https://www.ag-grid.com/forum/images/newfolder.gif" alt="New Posts" title="New Posts" /> New Posts</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/newhotfolder.gif" alt="Hot Thread (New)" title="Hot Thread (New)" /> Hot Thread (New)</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/hotfolder.gif" alt="Hot Thread (No New)" title="Hot Thread (No New)" /> Hot Thread (No New)</dd>
		</dl>
	</div>

	<div class="float_left">
		<dl class="thread_legend smalltext">
			<dd><img src="https://www.ag-grid.com/forum/images/folder.gif" alt="No New Posts" title="No New Posts" /> No New Posts</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/dot_folder.gif" alt="Contains Posts by You" title="Contains Posts by You" /> Contains Posts by You</dd>
			<dd><img src="https://www.ag-grid.com/forum/images/lockfolder.gif" alt="Locked Thread" title="Locked Thread" /> Locked Thread</dd>
		</dl>
	</div>
	<br style="clear: both" />
</div>

<div class="float_right" style="text-align: right;">
	
	<!-- start: forumdisplay_searchforum -->
<form action="https://www.ag-grid.com/forum/search.php" method="post">
	<span class="smalltext"><strong>Search this Forum:</strong></span>
	<input type="text" class="textbox" name="keywords" /> <!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	<input type="hidden" name="action" value="do_search" />
	<input type="hidden" name="forums" value="4" />
	<input type="hidden" name="postthread" value="1" />
	</form><br />
<!-- end: forumdisplay_searchforum -->
	<!-- start: forumjump_advanced -->
<form action="https://www.ag-grid.com/forum/forumdisplay.php" method="get">
<span class="smalltext"><strong>Forum Jump:</strong></span>
<select name="fid" class="forumjump">
<option value="-1" >Please select one:</option>
<option value="-1">--------------------</option>
<option value="-4">Private Messages</option>
<option value="-3">User Control Panel</option>
<option value="-5">Who's Online</option>
<option value="-2">Search</option>
<option value="-1">Forum Home</option>
<!-- start: forumjump_bit -->
<option value="3" > ag-Grid</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="4" selected="selected">-- ag-Grid Free Forum (not actively monitored by ag-Grid dev)</option>
<!-- end: forumjump_bit --><!-- start: forumjump_bit -->
<option value="5" >-- ag-Grid Members Forum (only members can post, monitored daily by ag-Grid dev)</option>
<!-- end: forumjump_bit -->
</select>
<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
</form>
<script type="text/javascript">
<!--
	$$('.forumjump').invoke('observe', 'change', function(e)
	{
		var option = this.options[this.selectedIndex].value

		if(option < 0)
		{
			window.location=('https://www.ag-grid.com/forum/forumdisplay.php?fid='+option)
			return
		}

		window.location=('https://www.ag-grid.com/forum/forumdisplay.php?fid='+this.options[this.selectedIndex].value)
	})
//-->
</script>
<!-- end: forumjump_advanced -->
</div>
<br style="clear: both" />
<!-- start: forumdisplay_threadlist_inlineedit_js -->
<script type="text/javascript" src="https://www.ag-grid.com/forum/jscripts/inline_edit.js?ver=1400"></script>
<script type="text/javascript">
<!--
	if(use_xmlhttprequest == "1")
	{
		new inlineEditor("https://www.ag-grid.com/forum/xmlhttp.php?action=edit_subject&amp;my_post_key="+my_post_key, {className: "subject_editable", spinnerImage: "images/spinner.gif", lang_click_edit: "(Click and hold to edit)"});
	}
// -->
</script>
<!-- end: forumdisplay_threadlist_inlineedit_js -->
<!-- end: forumdisplay_threadlist -->
<!-- start: footer -->
			<br />
			<div class="bottommenu">
				<div class="float_right"><!-- start: footer_languageselect -->
<form method="get" action="https://www.ag-grid.com/forum/forumdisplay.php" id="lang_select">
		<input type="hidden" name="fid" value="4" />
<input type="hidden" name="page" value="13" />
<input type="hidden" name="datecut" value="0" />
<input type="hidden" name="sortby" value="subject" />
<input type="hidden" name="order" value="asc" />

		<input type="hidden" name="my_post_key" value="9d9f8e6842db6d8c8a75a10edcf17276" />
		<select name="language" onchange="MyBB.changeLanguage();">
			<optgroup label="Quick Language Select">
				<option value="english" selected="selected">&nbsp;&nbsp;&nbsp;English (American)</option>

			</optgroup>
		</select>
		<!-- start: gobutton -->
<input type="submit" class="button" value="Go" />
<!-- end: gobutton -->
	</form>
<!-- end: footer_languageselect --></div>
				<div>
					<span class="smalltext"><a href="mailto:webmaster@angulargrid.com">Contact Us</a> | <a href="https://www.ag-grid.com/">ag-Grid Forum</a> | <a href="#top">Return to Top</a> | <a href="#content">Return to Content</a> | <a href="https://ag-grid.com/forum/archive/index.php?forum-4.html">Lite (Archive) Mode</a> | <a href="https://ag-grid.com/forum/misc.php?action=syndication">RSS Syndication</a></span>
				</div>
			</div>
			</div>
		<hr class="hidden" />
			<div id="copyright">
				<div id="debug"></div>
				<!-- MyBB is free software developed and maintained by a volunteer community.
					 It would be much appreciated by the MyBB Group if you left the full copyright and "powered by" notice intact,
					 to show your support for MyBB.  If you choose to remove or modify the copyright below,
					 you may be refused support on the MyBB Community Forums.

					 This is free software, support us and we'll support you. -->
Powered By <a href="http://mybb.com/" target="_blank">MyBB</a>, &copy; 2002-2016 <a href="http://mybb.com/" target="_blank">MyBB Group</a>.<br />
				<!-- End powered by -->
				<br />
<br class="clear" />
<!-- The following piece of code allows MyBB to run scheduled tasks. DO NOT REMOVE --><!-- End task image code -->

		</div>
		</div>
<!-- end: footer -->
</body>

<!-- Mirrored from www.ag-grid.com/forum/forumdisplay.php?fid=4&page=13&datecut=0&sortby=subject&order=asc by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2016 21:51:44 GMT -->
</html>
<!-- end: forumdisplay -->